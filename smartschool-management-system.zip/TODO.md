# SmartSchool Ghana — Delivery TODO

Status values: `[ ]` open, `[~]` in progress, `[x]` complete with implementation evidence.

## [~] 1. Foundation, authentication, tenancy and responsive shell

- [x] SmartSchool is initialized as a separate managed Web project and does not modify or reuse PULLINGS.
- [x] The application uses the managed web database starter with a server-backed React/Express/tRPC/Drizzle architecture.
- [x] Manus OAuth is used for application login; no simulated user or separate password system is introduced.
- [~] The application supports secure role-based access for Super Administrator, School Administrator, Headteacher/Principal, Accountant, Teacher, Student, Parent/Guardian and Librarian; implemented roles and server guards are in place, while linked portals and membership management remain open.
- [~] School-owned data is isolated by tenant, with server-enforced school membership and no cross-school reads or writes; implemented procedures use membership-derived school IDs, while multi-school selection and linked-record portals remain open.
- [x] The admin dashboard starts with zero-derived metrics and realistic empty states; no fake students, teachers, fees, payments, attendance or exams are seeded.
- [x] The UI is mobile-friendly across phone, tablet and desktop, with a persistent desktop rail and compact mobile navigation.
- [~] Every visible action in the delivered modules performs a real mutation, navigation, or clearly states why it is unavailable; reports/downloads and remaining module workflows are still open.

## [~] 2. School setup, branding and academic structure

- [~] School settings support name, code, contact details, address, region/town and motto; logo/branding and academic-year configuration remain open.
- [~] Administrators can manage nursery, kindergarten, primary, JHS and SHS levels and classes; departments, subjects, class teachers, terms and academic years remain open.
- [x] Implemented school, academic, staff, student, payment and announcement records persist through refresh, logout, restart and deployment because they are stored in the managed database.
- [~] Inputs are validated and duplicate codes/names are rejected by database constraints; friendly duplicate-error copy remains open.

## [~] 3. Admissions, people and profiles

- [~] Student admissions capture admission number, names, date of birth, gender, contact/address and a persistent managed-storage photograph reference; guardian links, level/class, status, admission date and notes workflow remain open.
- [~] Teacher/staff management supports staff profiles, job title, contact details, status and staff number; department, role membership and photo reference remain open.
- [ ] Parent/guardian records and student-guardian links support the parent portal and primary-contact designation.
- [ ] Users and memberships can be assigned only allowed roles within the current school, with auditability.

## [~] 4. Attendance, timetable and daily school operations

- [~] Authorized teachers and administrators can create one attendance session per class/date; per-student present, absent, late or excused records remain open.
- [ ] Attendance summaries are derived from stored records and remain empty/zero before any session is recorded.
- [x] Timetable entries store class, subject, teacher label, weekday, time and room, and the server rejects overlapping class or room bookings.
- [~] Communication centre supports published school announcements with audience filtering; direct messages and read state remain open.

## [~] 5. Fees, finance and Ghana payment methods

- [~] Verified receipt recording and finance summaries are database-backed; fee structures, student charges, balances, discounts and expenses remain open.
- [x] Payment recording supports cash, MTN Mobile Money, Telecel Cash, AT Money and bank transfer, with receipt number, amount, date, verification status and provider reference where applicable.
- [ ] Paystack remains unavailable unless securely configured and verified server-side; no secret key is exposed to browser code.
- [ ] New-school financial totals start at zero and never display fabricated revenue, balances or transactions.
- [~] Accountant-only actions are protected from unauthorized roles and finance mutations are scoped to the school; audit-log persistence remains open.

## [~] 6. Exams, grades, report cards and portals

- [~] Authorized staff can create assessment records; exam subjects, validated scores, derived grades/remarks and published report cards remain open.
- [ ] Parents can see only linked learners, their balances, attendance, announcements and published report cards.
- [ ] Students can see only their own timetable, attendance, grades and published report cards.
- [ ] Grade and report-card data obeys the active school tenant and role boundaries.

## [~] 7. Library, assets and inventory

- [~] Librarians can manage books, copies, categories, shelves and available counts; issue/return circulation remains open.
- [ ] Authorized users can issue/return books with due dates and borrower links while preventing invalid availability counts.
- [~] Assets/inventory supports asset tags, quantities, condition, location and status; purchase dates and values remain open.
- [x] Library and asset records persist and support useful empty states before setup.

## [~] 8. Reports, downloads, settings and hardening

- [~] Reports provide downloadable CSV outputs for admissions and finance with tenant-safe protected queries; attendance, exams, library and assets exports remain open.
- [ ] School branding/settings are used consistently in the shell and report output where configured.
- [x] Database schema/migrations are committed and additive; no destructive migration or test cleanup is run against shared managed data without approval.
- [x] Local, VS Code and deployment instructions are documented, including environment, migration, check, test and start commands.
- [~] Major workflows are checked with code inspection, diagnostics and focused workflow verification before delivery; public entry, health, route manifest, build, tests and implemented persistence paths are checked, while unresolved requirements remain open rather than being represented as complete.
