import { TRPCError } from "@trpc/server";
import { getSchoolContextForUser } from "./db";

export const roles = [
  "super_admin",
  "school_admin",
  "headteacher",
  "accountant",
  "teacher",
  "student",
  "parent",
  "librarian",
] as const;

export type SchoolRole = (typeof roles)[number];

export async function requireSchoolContext(userId: number) {
  const context = await getSchoolContextForUser(userId);
  if (!context) {
    throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Complete school setup before using this workspace." });
  }
  return context;
}

export function requireRole(role: string, allowed: readonly SchoolRole[]) {
  if (!allowed.includes(role as SchoolRole)) {
    throw new TRPCError({ code: "FORBIDDEN", message: "Your role does not have permission for this action." });
  }
}

export function canManageSchool(role: string) {
  requireRole(role, ["super_admin", "school_admin"]);
}

export function canManageStudents(role: string) {
  requireRole(role, ["super_admin", "school_admin", "headteacher", "teacher"]);
}
