import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import {
  createSchoolForUser,
  createAnnouncement,
  createAsset,
  createAttendanceSession,
  createBook,
  createClass,
  createExam,
  createLevel,
  createPayment,
  createStaff,
  createTimetableEntry,
  createStudent,
  getAcademicStructure,
  getDashboardData,
  getSchoolContextForUser,
  listAnnouncements,
  listAssets,
  listAttendanceSessions,
  listBooks,
  listExams,
  listPayments,
  listStaff,
  listStudents,
  listTimetableEntries,
  updateSchool,
} from "./db";
import { canManageSchool, canManageStudents, requireRole, requireSchoolContext } from "./permissions";

const schoolInput = z.object({
  name: z.string().trim().min(2, "School name is required").max(180),
  code: z.string().trim().min(2, "School code is required").max(32),
  motto: z.string().trim().max(255).optional(),
  region: z.string().trim().max(80).optional(),
  town: z.string().trim().max(100).optional(),
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  school: router({
    context: protectedProcedure.query(({ ctx }) => getSchoolContextForUser(ctx.user.id)),
    create: protectedProcedure.input(schoolInput).mutation(async ({ ctx, input }) => {
      const existing = await getSchoolContextForUser(ctx.user.id);
      if (existing) {
        throw new TRPCError({ code: "CONFLICT", message: "You already have a school workspace." });
      }
      return createSchoolForUser(ctx.user.id, input);
    }),
    update: protectedProcedure.input(schoolInput.partial().extend({
      phone: z.string().trim().max(40).nullable().optional(),
      email: z.string().trim().email().max(320).nullable().optional(),
      address: z.string().trim().max(2000).nullable().optional(),
    })).mutation(async ({ ctx, input }) => {
      const context = await requireSchoolContext(ctx.user.id);
      canManageSchool(context.membership.role);
      return updateSchool(context.school.id, input);
    }),
  }),

  dashboard: protectedProcedure.query(async ({ ctx }) => {
    const context = await requireSchoolContext(ctx.user.id);
    requireRole(context.membership.role, ["super_admin", "school_admin", "headteacher", "accountant", "teacher", "librarian"]);
    return getDashboardData(context.school.id);
  }),

  students: router({
    list: protectedProcedure.input(z.object({ search: z.string().trim().max(80).optional() })).query(async ({ ctx, input }) => {
      const context = await requireSchoolContext(ctx.user.id);
      requireRole(context.membership.role, ["super_admin", "school_admin", "headteacher", "teacher"]);
      return listStudents(context.school.id, input.search);
    }),
    create: protectedProcedure.input(z.object({
      admissionNumber: z.string().trim().min(1, "Admission number is required").max(50),
      firstName: z.string().trim().min(1, "First name is required").max(100),
      middleName: z.string().trim().max(100).optional(),
      lastName: z.string().trim().min(1, "Last name is required").max(100),
      dateOfBirth: z.coerce.date().optional(),
      gender: z.enum(["female", "male", "other"]).optional(),
      phone: z.string().trim().max(40).optional(),
      email: z.string().trim().email().max(320).optional().or(z.literal("")),
      address: z.string().trim().max(2000).optional(),
      notes: z.string().trim().max(2000).optional(),
      photoData: z.string().max(7_000_000).optional(),
    })).mutation(async ({ ctx, input }) => {
      const context = await requireSchoolContext(ctx.user.id);
      canManageStudents(context.membership.role);
      return createStudent(context.school.id, input);
    }),
  }),

  academics: router({
    structure: protectedProcedure.query(async ({ ctx }) => {
      const context = await requireSchoolContext(ctx.user.id);
      requireRole(context.membership.role, ["super_admin", "school_admin", "headteacher", "teacher"]);
      return getAcademicStructure(context.school.id);
    }),
    createLevel: protectedProcedure.input(z.object({ name: z.string().trim().min(2).max(100), stage: z.enum(["nursery", "kindergarten", "primary", "jhs", "shs"]) })).mutation(async ({ ctx, input }) => {
      const context = await requireSchoolContext(ctx.user.id);
      requireRole(context.membership.role, ["super_admin", "school_admin", "headteacher"]);
      return createLevel(context.school.id, input);
    }),
    createClass: protectedProcedure.input(z.object({ name: z.string().trim().min(2).max(120), code: z.string().trim().min(1).max(30), levelId: z.number().int().positive().optional(), capacity: z.number().int().min(0).max(10000).optional() })).mutation(async ({ ctx, input }) => {
      const context = await requireSchoolContext(ctx.user.id);
      requireRole(context.membership.role, ["super_admin", "school_admin", "headteacher"]);
      return createClass(context.school.id, input);
    }),
  }),

  staff: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      const context = await requireSchoolContext(ctx.user.id);
      requireRole(context.membership.role, ["super_admin", "school_admin", "headteacher"]);
      return listStaff(context.school.id);
    }),
    create: protectedProcedure.input(z.object({ staffNumber: z.string().trim().min(1).max(50), firstName: z.string().trim().min(1).max(100), lastName: z.string().trim().min(1).max(100), jobTitle: z.string().trim().min(2).max(120), phone: z.string().trim().max(40).optional(), email: z.string().trim().email().max(320).optional().or(z.literal("")) })).mutation(async ({ ctx, input }) => {
      const context = await requireSchoolContext(ctx.user.id);
      requireRole(context.membership.role, ["super_admin", "school_admin", "headteacher"]);
      return createStaff(context.school.id, input);
    }),
  }),

  finance: router({
    payments: protectedProcedure.query(async ({ ctx }) => {
      const context = await requireSchoolContext(ctx.user.id);
      requireRole(context.membership.role, ["super_admin", "school_admin", "headteacher", "accountant"]);
      return listPayments(context.school.id);
    }),
    recordPayment: protectedProcedure.input(z.object({ receiptNumber: z.string().trim().min(1).max(60), amount: z.string().trim().regex(/^\d+(\.\d{1,2})?$/), method: z.enum(["cash", "mtn_momo", "telecel_cash", "at_money", "bank_transfer"]), providerReference: z.string().trim().max(160).optional() })).mutation(async ({ ctx, input }) => {
      const context = await requireSchoolContext(ctx.user.id);
      requireRole(context.membership.role, ["super_admin", "school_admin", "accountant"]);
      return createPayment(context.school.id, ctx.user.id, input);
    }),
  }),

  communications: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      const context = await requireSchoolContext(ctx.user.id);
      return listAnnouncements(context.school.id, context.membership.role);
    }),
    publish: protectedProcedure.input(z.object({ title: z.string().trim().min(3).max(180), body: z.string().trim().min(3).max(5000), audience: z.enum(["all", "staff", "students", "parents"]) })).mutation(async ({ ctx, input }) => {
      const context = await requireSchoolContext(ctx.user.id);
      requireRole(context.membership.role, ["super_admin", "school_admin", "headteacher", "teacher"]);
      return createAnnouncement(context.school.id, ctx.user.id, input);
    }),
  }),

  attendance: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      const context = await requireSchoolContext(ctx.user.id);
      requireRole(context.membership.role, ["super_admin", "school_admin", "headteacher", "teacher"]);
      return listAttendanceSessions(context.school.id);
    }),
    createSession: protectedProcedure.input(z.object({ classId: z.number().int().positive(), date: z.coerce.date() })).mutation(async ({ ctx, input }) => {
      const context = await requireSchoolContext(ctx.user.id);
      requireRole(context.membership.role, ["super_admin", "school_admin", "headteacher", "teacher"]);
      return createAttendanceSession(context.school.id, ctx.user.id, input);
    }),
  }),

  timetable: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      const context = await requireSchoolContext(ctx.user.id);
      requireRole(context.membership.role, ["super_admin", "school_admin", "headteacher", "teacher"]);
      return listTimetableEntries(context.school.id);
    }),
    create: protectedProcedure.input(z.object({ classId: z.number().int().positive().optional(), subjectLabel: z.string().trim().min(2).max(120), teacherLabel: z.string().trim().max(160).optional(), weekday: z.enum(["monday", "tuesday", "wednesday", "thursday", "friday", "saturday"]), startTime: z.string().regex(/^\d{2}:\d{2}$/), endTime: z.string().regex(/^\d{2}:\d{2}$/), room: z.string().trim().max(80).optional() })).mutation(async ({ ctx, input }) => {
      const context = await requireSchoolContext(ctx.user.id);
      requireRole(context.membership.role, ["super_admin", "school_admin", "headteacher", "teacher"]);
      return createTimetableEntry(context.school.id, input);
    }),
  }),

  exams: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      const context = await requireSchoolContext(ctx.user.id);
      requireRole(context.membership.role, ["super_admin", "school_admin", "headteacher", "teacher"]);
      return listExams(context.school.id);
    }),
    create: protectedProcedure.input(z.object({ title: z.string().trim().min(3).max(180), type: z.string().trim().min(2).max(60), startsOn: z.coerce.date(), endsOn: z.coerce.date().optional() })).mutation(async ({ ctx, input }) => {
      const context = await requireSchoolContext(ctx.user.id);
      requireRole(context.membership.role, ["super_admin", "school_admin", "headteacher", "teacher"]);
      return createExam(context.school.id, input);
    }),
  }),

  library: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      const context = await requireSchoolContext(ctx.user.id);
      requireRole(context.membership.role, ["super_admin", "school_admin", "headteacher", "teacher", "librarian"]);
      return listBooks(context.school.id);
    }),
    create: protectedProcedure.input(z.object({ title: z.string().trim().min(2).max(180), author: z.string().trim().max(160).optional(), category: z.string().trim().max(100).optional(), totalCopies: z.number().int().min(1).max(100000), shelf: z.string().trim().max(80).optional(), isbn: z.string().trim().max(40).optional() })).mutation(async ({ ctx, input }) => {
      const context = await requireSchoolContext(ctx.user.id);
      requireRole(context.membership.role, ["super_admin", "school_admin", "librarian"]);
      return createBook(context.school.id, input);
    }),
  }),

  assets: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      const context = await requireSchoolContext(ctx.user.id);
      requireRole(context.membership.role, ["super_admin", "school_admin", "headteacher", "accountant"]);
      return listAssets(context.school.id);
    }),
    create: protectedProcedure.input(z.object({ assetTag: z.string().trim().min(1).max(60), name: z.string().trim().min(2).max(180), category: z.string().trim().max(100).optional(), quantity: z.number().int().min(1).max(100000), condition: z.string().trim().max(60).optional(), location: z.string().trim().max(120).optional() })).mutation(async ({ ctx, input }) => {
      const context = await requireSchoolContext(ctx.user.id);
      requireRole(context.membership.role, ["super_admin", "school_admin", "headteacher", "accountant"]);
      return createAsset(context.school.id, input);
    }),
  }),
});

export type AppRouter = typeof appRouter;
