import { and, count, desc, eq, like, or, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  announcements,
  academicYears,
  attendanceSessions,
  attendanceRecords,
  assets,
  classes,
  departments,
  expenses,
  exams,
  libraryBooks,
  levels,
  payments,
  schools,
  schoolMemberships,
  staffProfiles,
  students,
  subjects,
  timetableEntries,
  users,
  type InsertUser,
} from "../drizzle/schema";
import { ENV } from "./_core/env";
import { storagePut } from "./storage";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && (process.env.DATABASE_URL || ENV.databaseUrl)) {
    try {
      _db = drizzle(process.env.DATABASE_URL || ENV.databaseUrl);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) throw new Error("Database is not available");

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  for (const field of textFields) {
    if (user[field] !== undefined) {
      values[field] = user[field] ?? null;
      updateSet[field] = user[field] ?? null;
    }
  }
  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  values.lastSignedIn ??= new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function getSchoolContextForUser(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const result = await db
    .select({ school: schools, membership: schoolMemberships })
    .from(schoolMemberships)
    .innerJoin(schools, eq(schoolMemberships.schoolId, schools.id))
    .where(and(eq(schoolMemberships.userId, userId), eq(schoolMemberships.status, "active")))
    .orderBy(desc(schoolMemberships.createdAt))
    .limit(1);
  return result[0] ?? null;
}

export async function createSchoolForUser(userId: number, input: {
  name: string;
  code: string;
  motto?: string;
  region?: string;
  town?: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const slug = input.name.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "") || `school-${Date.now()}`;
  const result = await db.insert(schools).values({
    name: input.name.trim(),
    code: input.code.trim().toUpperCase(),
    slug,
    motto: input.motto?.trim() || null,
    region: input.region?.trim() || null,
    town: input.town?.trim() || null,
  });
  const schoolId = Number(result[0].insertId);
  await db.insert(schoolMemberships).values({ schoolId, userId, role: "school_admin", status: "active" });
  return getSchoolContextForUser(userId);
}

export async function updateSchool(schoolId: number, input: {
  name?: string;
  code?: string;
  motto?: string | null;
  phone?: string | null;
  email?: string | null;
  address?: string | null;
  region?: string | null;
  town?: string | null;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(schools).set({
    ...input,
    name: input.name?.trim(),
    code: input.code?.trim().toUpperCase(),
  }).where(eq(schools.id, schoolId));
  return db.select().from(schools).where(eq(schools.id, schoolId)).limit(1).then(rows => rows[0] ?? null);
}

async function scalarCount(query: Promise<Array<{ value: number | bigint }>>) {
  const rows = await query;
  return Number(rows[0]?.value ?? 0);
}

export async function getDashboardData(schoolId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const [studentCount, staffCount, classCount, announcementCount, attendanceCount, paymentTotal, expenseTotal, recentStudents] = await Promise.all([
    scalarCount(db.select({ value: count() }).from(students).where(eq(students.schoolId, schoolId))),
    scalarCount(db.select({ value: count() }).from(staffProfiles).where(eq(staffProfiles.schoolId, schoolId))),
    scalarCount(db.select({ value: count() }).from(classes).where(eq(classes.schoolId, schoolId))),
    scalarCount(db.select({ value: count() }).from(announcements).where(and(eq(announcements.schoolId, schoolId), eq(announcements.status, "published")))),
    scalarCount(db.select({ value: count() }).from(attendanceSessions).where(eq(attendanceSessions.schoolId, schoolId))),
    db.select({ value: sql<string>`COALESCE(SUM(CAST(${payments.amount} AS DECIMAL(14,2))), 0)` }).from(payments).where(and(eq(payments.schoolId, schoolId), eq(payments.status, "verified"))),
    db.select({ value: sql<string>`COALESCE(SUM(CAST(${expenses.amount} AS DECIMAL(14,2))), 0)` }).from(expenses).where(and(eq(expenses.schoolId, schoolId), eq(expenses.status, "approved"))),
    db.select({
      id: students.id,
      name: sql<string>`CONCAT(${students.firstName}, ' ', ${students.lastName})`,
      admissionNumber: students.admissionNumber,
      status: students.status,
      createdAt: students.createdAt,
    }).from(students).where(eq(students.schoolId, schoolId)).orderBy(desc(students.createdAt)).limit(5),
  ]);
  return {
    counts: {
      students: studentCount,
      staff: staffCount,
      classes: classCount,
      announcements: announcementCount,
      attendanceSessions: attendanceCount,
    },
    finance: {
      payments: Number(paymentTotal[0]?.value ?? 0),
      expenses: Number(expenseTotal[0]?.value ?? 0),
    },
    recentStudents,
  };
}

export async function listStudents(schoolId: number, search?: string) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const normalized = search?.trim();
  const searchFilter = normalized
    ? or(
        like(students.firstName, `%${normalized}%`),
        like(students.lastName, `%${normalized}%`),
        like(students.admissionNumber, `%${normalized}%`),
      )
    : undefined;
  return db.select().from(students)
    .where(searchFilter ? and(eq(students.schoolId, schoolId), searchFilter) : eq(students.schoolId, schoolId))
    .orderBy(desc(students.createdAt));
}

export async function createStudent(schoolId: number, input: {
  admissionNumber: string;
  firstName: string;
  middleName?: string;
  lastName: string;
  dateOfBirth?: Date;
  gender?: "female" | "male" | "other";
  phone?: string;
  email?: string;
  address?: string;
  notes?: string;
  photoData?: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  let photoUrl: string | null = null;
  if (input.photoData) {
    const match = input.photoData.match(/^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=]+)$/);
    if (!match) throw new Error("Student photo must be a PNG, JPEG or WebP image.");
    const photoBuffer = Buffer.from(match[2], "base64");
    if (photoBuffer.byteLength > 5 * 1024 * 1024) throw new Error("Student photo must be 5MB or smaller.");
    const uploaded = await storagePut(`schools/${schoolId}/students/${input.admissionNumber.trim().toLowerCase()}.image`, photoBuffer, match[1]);
    photoUrl = uploaded.url;
  }
  const result = await db.insert(students).values({
    schoolId,
    admissionNumber: input.admissionNumber.trim().toUpperCase(),
    firstName: input.firstName.trim(),
    middleName: input.middleName?.trim() || null,
    lastName: input.lastName.trim(),
    dateOfBirth: input.dateOfBirth ?? null,
    gender: input.gender ?? null,
    phone: input.phone?.trim() || null,
    email: input.email?.trim() || null,
    address: input.address?.trim() || null,
    notes: input.notes?.trim() || null,
    photoUrl,
  });
  const id = Number(result[0].insertId);
  const rows = await db.select().from(students).where(and(eq(students.id, id), eq(students.schoolId, schoolId))).limit(1);
  return rows[0];
}

export async function getAcademicStructure(schoolId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const [levelRows, classRows, subjectRows, departmentRows] = await Promise.all([
    db.select().from(levels).where(eq(levels.schoolId, schoolId)).orderBy(levels.sortOrder),
    db.select().from(classes).where(eq(classes.schoolId, schoolId)).orderBy(classes.name),
    db.select().from(subjects).where(eq(subjects.schoolId, schoolId)).orderBy(subjects.name),
    db.select().from(departments).where(eq(departments.schoolId, schoolId)).orderBy(departments.name),
  ]);
  return { levels: levelRows, classes: classRows, subjects: subjectRows, departments: departmentRows };
}

export async function createLevel(schoolId: number, input: { name: string; stage: "nursery" | "kindergarten" | "primary" | "jhs" | "shs" }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const result = await db.insert(levels).values({ schoolId, name: input.name.trim(), stage: input.stage });
  const rows = await db.select().from(levels).where(and(eq(levels.id, Number(result[0].insertId)), eq(levels.schoolId, schoolId))).limit(1);
  return rows[0];
}

export async function createClass(schoolId: number, input: { name: string; code: string; levelId?: number; capacity?: number }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  if (input.levelId) {
    const level = await db.select({ id: levels.id }).from(levels).where(and(eq(levels.id, input.levelId), eq(levels.schoolId, schoolId))).limit(1);
    if (!level[0]) throw new Error("Selected level does not belong to this school.");
  }
  const result = await db.insert(classes).values({ schoolId, name: input.name.trim(), code: input.code.trim().toUpperCase(), levelId: input.levelId ?? null, capacity: input.capacity ?? 0 });
  const rows = await db.select().from(classes).where(and(eq(classes.id, Number(result[0].insertId)), eq(classes.schoolId, schoolId))).limit(1);
  return rows[0];
}

export async function listStaff(schoolId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  return db.select().from(staffProfiles).where(eq(staffProfiles.schoolId, schoolId)).orderBy(desc(staffProfiles.createdAt));
}

export async function createStaff(schoolId: number, input: { staffNumber: string; firstName: string; lastName: string; jobTitle: string; phone?: string; email?: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const result = await db.insert(staffProfiles).values({ schoolId, staffNumber: input.staffNumber.trim().toUpperCase(), firstName: input.firstName.trim(), lastName: input.lastName.trim(), jobTitle: input.jobTitle.trim(), phone: input.phone?.trim() || null, email: input.email?.trim() || null });
  const rows = await db.select().from(staffProfiles).where(and(eq(staffProfiles.id, Number(result[0].insertId)), eq(staffProfiles.schoolId, schoolId))).limit(1);
  return rows[0];
}

export async function listPayments(schoolId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  return db.select().from(payments).where(eq(payments.schoolId, schoolId)).orderBy(desc(payments.paidOn));
}

export async function createPayment(schoolId: number, userId: number, input: { receiptNumber: string; amount: string; method: "cash" | "mtn_momo" | "telecel_cash" | "at_money" | "bank_transfer"; providerReference?: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const amount = Number(input.amount);
  if (!Number.isFinite(amount) || amount <= 0) throw new Error("Payment amount must be greater than zero.");
  const result = await db.insert(payments).values({ schoolId, receivedByUserId: userId, receiptNumber: input.receiptNumber.trim().toUpperCase(), amount: amount.toFixed(2), method: input.method, providerReference: input.providerReference?.trim() || null, status: "verified" });
  const rows = await db.select().from(payments).where(and(eq(payments.id, Number(result[0].insertId)), eq(payments.schoolId, schoolId))).limit(1);
  return rows[0];
}

export async function listAnnouncements(schoolId: number, role: string) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const audience = role === "parent" ? "parents" : role === "student" ? "students" : ["teacher", "librarian"].includes(role) ? "staff" : null;
  const audienceFilter = audience ? or(eq(announcements.audience, "all"), eq(announcements.audience, audience)) : undefined;
  return db.select().from(announcements).where(audienceFilter
    ? and(eq(announcements.schoolId, schoolId), eq(announcements.status, "published"), audienceFilter)
    : and(eq(announcements.schoolId, schoolId), eq(announcements.status, "published"))).orderBy(desc(announcements.createdAt));
}

export async function createAnnouncement(schoolId: number, userId: number, input: { title: string; body: string; audience: "all" | "staff" | "students" | "parents" }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const result = await db.insert(announcements).values({ schoolId, publishedByUserId: userId, title: input.title.trim(), body: input.body.trim(), audience: input.audience, status: "published", publishedAt: new Date() });
  const rows = await db.select().from(announcements).where(and(eq(announcements.id, Number(result[0].insertId)), eq(announcements.schoolId, schoolId))).limit(1);
  return rows[0];
}

export async function listAttendanceSessions(schoolId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  return db.select().from(attendanceSessions).where(eq(attendanceSessions.schoolId, schoolId)).orderBy(desc(attendanceSessions.date));
}

export async function createAttendanceSession(schoolId: number, userId: number, input: { classId: number; date: Date }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const classRow = await db.select({ id: classes.id }).from(classes).where(and(eq(classes.id, input.classId), eq(classes.schoolId, schoolId))).limit(1);
  if (!classRow[0]) throw new Error("Selected class does not belong to this school.");
  const result = await db.insert(attendanceSessions).values({ schoolId, classId: input.classId, date: input.date, takenByUserId: userId, status: "draft" });
  const rows = await db.select().from(attendanceSessions).where(and(eq(attendanceSessions.id, Number(result[0].insertId)), eq(attendanceSessions.schoolId, schoolId))).limit(1);
  return rows[0];
}

export async function listTimetableEntries(schoolId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  return db.select().from(timetableEntries).where(eq(timetableEntries.schoolId, schoolId)).orderBy(timetableEntries.weekday, timetableEntries.startTime);
}

export async function createTimetableEntry(schoolId: number, input: { classId?: number; subjectLabel: string; teacherLabel?: string; weekday: "monday" | "tuesday" | "wednesday" | "thursday" | "friday" | "saturday"; startTime: string; endTime: string; room?: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  if (input.startTime >= input.endTime) throw new Error("End time must be later than start time.");
  if (input.classId) {
    const classRow = await db.select({ id: classes.id }).from(classes).where(and(eq(classes.id, input.classId), eq(classes.schoolId, schoolId))).limit(1);
    if (!classRow[0]) throw new Error("Selected class does not belong to this school.");
  }
  const existing = await db.select().from(timetableEntries).where(and(eq(timetableEntries.schoolId, schoolId), eq(timetableEntries.weekday, input.weekday)));
  const overlaps = existing.some(entry => (input.classId && entry.classId === input.classId || input.room && entry.room === input.room) && input.startTime < entry.endTime && input.endTime > entry.startTime);
  if (overlaps) throw new Error("This entry conflicts with an existing class or room booking.");
  const result = await db.insert(timetableEntries).values({ schoolId, classId: input.classId ?? null, subjectLabel: input.subjectLabel.trim(), teacherLabel: input.teacherLabel?.trim() || null, weekday: input.weekday, startTime: input.startTime, endTime: input.endTime, room: input.room?.trim() || null });
  const rows = await db.select().from(timetableEntries).where(and(eq(timetableEntries.id, Number(result[0].insertId)), eq(timetableEntries.schoolId, schoolId))).limit(1);
  return rows[0];
}

export async function listExams(schoolId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  return db.select().from(exams).where(eq(exams.schoolId, schoolId)).orderBy(desc(exams.startsOn));
}

export async function createExam(schoolId: number, input: { title: string; type: string; startsOn: Date; endsOn?: Date }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const result = await db.insert(exams).values({ schoolId, title: input.title.trim(), type: input.type.trim(), startsOn: input.startsOn, endsOn: input.endsOn ?? null, status: "draft" });
  const rows = await db.select().from(exams).where(and(eq(exams.id, Number(result[0].insertId)), eq(exams.schoolId, schoolId))).limit(1);
  return rows[0];
}

export async function listBooks(schoolId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  return db.select().from(libraryBooks).where(eq(libraryBooks.schoolId, schoolId)).orderBy(libraryBooks.title);
}

export async function createBook(schoolId: number, input: { title: string; author?: string; category?: string; totalCopies: number; shelf?: string; isbn?: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  if (input.totalCopies < 1) throw new Error("A book must have at least one copy.");
  const result = await db.insert(libraryBooks).values({ schoolId, title: input.title.trim(), author: input.author?.trim() || null, category: input.category?.trim() || null, totalCopies: input.totalCopies, availableCopies: input.totalCopies, shelf: input.shelf?.trim() || null, isbn: input.isbn?.trim() || null });
  const rows = await db.select().from(libraryBooks).where(and(eq(libraryBooks.id, Number(result[0].insertId)), eq(libraryBooks.schoolId, schoolId))).limit(1);
  return rows[0];
}

export async function listAssets(schoolId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  return db.select().from(assets).where(eq(assets.schoolId, schoolId)).orderBy(desc(assets.createdAt));
}

export async function createAsset(schoolId: number, input: { assetTag: string; name: string; category?: string; quantity: number; condition?: string; location?: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  if (input.quantity < 1) throw new Error("Quantity must be at least one.");
  const result = await db.insert(assets).values({ schoolId, assetTag: input.assetTag.trim().toUpperCase(), name: input.name.trim(), category: input.category?.trim() || null, quantity: input.quantity, condition: input.condition?.trim() || null, location: input.location?.trim() || null, status: "active" });
  const rows = await db.select().from(assets).where(and(eq(assets.id, Number(result[0].insertId)), eq(assets.schoolId, schoolId))).limit(1);
  return rows[0];
}
