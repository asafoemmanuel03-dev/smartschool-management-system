# SmartSchool Ghana — Architecture & Implementation Plan

## Product intent

SmartSchool is a tenant-isolated school operations platform for Ghanaian schools spanning nursery, kindergarten, primary, JHS and SHS. It is built as a real full-stack web application on the managed Web database starter, using Manus OAuth for identity, application roles for authorization, and durable relational records for every business workflow. A newly created school starts clean: all counts, financial values and activity feeds are derived from stored records and therefore remain zero/empty until a user creates data.

This project is independent from PULLINGS and has its own managed Webdev resource, source tree, database, migrations and checkpoints.

## Technical architecture

- **Frontend:** React 19 + TypeScript + Vite, Wouter routing, Tailwind CSS v4, Radix-based UI primitives, TanStack Query via tRPC, Recharts for future reporting visualizations, responsive layouts optimized for phone, tablet and desktop.
- **Backend:** Express on the managed server runtime, tRPC routers for typed application APIs, Drizzle ORM against managed MySQL, object-storage paths for durable photographs and school branding assets.
- **Authentication:** Manus OAuth starter flow, preserving the `webdev_app_session` cookie contract and Preview-safe `SameSite=None; Secure` behavior. The Manus identity is mapped to an application user record; no simulated login or browser-storage database is used.
- **Authorization:** Explicit application roles: `super_admin`, `school_admin`, `headteacher`, `accountant`, `teacher`, `student`, `parent`, `librarian`. Every protected procedure resolves the caller's school membership and scopes all reads/writes through that membership. Super administrators can manage schools; ordinary users cannot cross tenant boundaries.
- **Persistence:** All core data in normalized MySQL tables with foreign keys, unique constraints and timestamps. Uploaded photographs/documents are stored in durable storage and referenced by database rows. No seed students, teachers, fees, payments, attendance, exams or fake dashboard metrics.
- **Validation:** Zod input validation at tRPC boundaries, server-side role/tenant checks, database constraints for uniqueness and conflict prevention, user-friendly client validation and error toasts.
- **Payments:** Fee records support cash, MTN Mobile Money, Telecel Cash, AT Money and bank transfer as manually verified methods. Paystack is feature-gated and must remain unavailable until a securely configured and verified server-side credential/verification flow exists; no secret is exposed to the browser.

## Relational database design

The starter `users` table remains the identity anchor. The application schema extends it as follows; all tenant-owned tables carry `schoolId` (or reach it through a school-owned parent) and should be queried with an explicit school scope.

### Identity and tenancy

- `schools`: id, name, code, slug, logoUrl, phone, email, address, region, town, motto, currency, academicYearLabel, settingsJson, createdAt, updatedAt, status.
- `schoolMemberships`: id, schoolId, userId, role, staff/student/guardian reference, status, createdAt; unique schoolId+userId.
- `schoolInvites`: id, schoolId, email, role, tokenHash, expiresAt, acceptedAt.
- `auditLogs`: id, schoolId, actorUserId, action, entityType, entityId, metadataJson, createdAt.

### Academic structure

- `academicYears`: id, schoolId, name, startsOn, endsOn, isCurrent.
- `terms`: id, schoolId, academicYearId, name, startsOn, endsOn, isCurrent, status.
- `levels`: id, schoolId, name, stage (nursery/kindergarten/primary/jhs/shs), sortOrder.
- `departments`: id, schoolId, name, code.
- `classes`: id, schoolId, levelId, departmentId, name, code, stream, capacity, classTeacherMembershipId.
- `subjects`: id, schoolId, departmentId, code, name, stage, isCore.
- `classSubjects`: id, schoolId, classId, subjectId, teacherMembershipId, periodsPerWeek.

### People and admissions

- `students`: id, schoolId, admissionNumber, firstName, middleName, lastName, dateOfBirth, gender, nationalId, photoUrl, phone, email, address, status, admissionDate, notes.
- `guardians`: id, schoolId, userId nullable, name, relationship, phone, email, address.
- `studentGuardians`: id, schoolId, studentId, guardianId, isPrimary.
- `studentEnrollments`: id, schoolId, studentId, academicYearId, termId, classId, rollNumber, status; unique student+term.
- `staffProfiles`: id, schoolId, userId nullable, staffNumber, firstName, lastName, jobTitle, phone, email, photoUrl, departmentId, employmentStatus, joinedOn.

### Teaching and assessment

- `attendanceSessions`: id, schoolId, classId, termId, date, takenByUserId, status; unique class+date.
- `attendanceRecords`: id, schoolId, sessionId, studentId, status (present/absent/late/excused), note; unique session+student.
- `exams`: id, schoolId, termId, title, type, startsOn, endsOn, status.
- `examSubjects`: id, schoolId, examId, classId, subjectId, maxScore, passScore.
- `grades`: id, schoolId, examSubjectId, studentId, score, grade, remark, enteredByUserId; unique examSubject+student.
- `reportCards`: id, schoolId, studentId, termId, publishedAt, publishedByUserId, summary, pdfUrl.

### Timetables

- `timetableEntries`: id, schoolId, termId, classId, subjectId, teacherMembershipId, weekday, startTime, endTime, room, status. Server conflict checks reject overlaps for a class, teacher or room within the same term.

### Fees and finance

- `feeStructures`: id, schoolId, academicYearId, termId, classId nullable, name, amount, dueOn, status.
- `studentCharges`: id, schoolId, studentId, feeStructureId, amount, discount, balance, status.
- `payments`: id, schoolId, studentId, chargeId nullable, receiptNumber, amount, method, providerReference, status, paidOn, receivedByUserId, verifiedAt, notes.
- `expenses`: id, schoolId, category, description, amount, expenseDate, paymentMethod, status, recordedByUserId.
- `paymentSettings`: id, schoolId, paystackEnabled, paystackPublicKey, verificationStatus, verifiedAt; secret keys are never stored in client-accessible data.

### Library, communications and assets

- `libraryBooks`: id, schoolId, isbn, title, author, category, totalCopies, availableCopies, shelf, coverUrl.
- `libraryLoans`: id, schoolId, bookId, borrowerStudentId nullable, borrowerUserId nullable, issuedOn, dueOn, returnedOn, status, issuedByUserId.
- `announcements`: id, schoolId, title, body, audience, publishedAt, publishedByUserId, status.
- `messages`: id, schoolId, senderUserId, recipientUserId nullable, subject, body, readAt, createdAt.
- `assets`: id, schoolId, assetTag, name, category, quantity, condition, location, purchaseDate, value, status.
- `reportExports`: id, schoolId, requestedByUserId, type, filtersJson, fileUrl, createdAt.

## Tenant and role rules

1. Every request that touches school data resolves `schoolId` from the authenticated membership or an explicitly selected school only for `super_admin` users.
2. Server procedures always add the tenant predicate; client-provided IDs are never trusted as tenant authorization.
3. School administrators and headteachers can manage academic and people records for their school; accountants manage fees, payments and expenses; teachers manage assigned classes/subjects, attendance and grades; librarians manage library records; parents and students only see their linked records; super administrators manage schools and memberships.
4. Mutations write an audit record where the action affects identity, finance, grades, attendance, settings or permissions.
5. Sensitive payment-provider configuration is protected by server-side secrets and verification status; unverified Paystack is shown as disabled, not as a working payment path.

## Product shell and design system

### Design options considered

- **Civic Ledger / editorial utility — 0.07:** warm paper surfaces, deep ink typography and a restrained green signal color for trustworthy school operations.
- **Coastal dashboard — 0.05:** airy blue panels, rounded cards and optimistic gradients.
- **Academic atelier — 0.04:** monochrome workspace with burgundy accents and bookish serif headlines.

**Chosen direction: Civic Ledger / editorial utility.**

- **Design movement:** contemporary civic-service design blended with editorial school administration software.
- **Core principles:** calm over noisy; evidence over decoration; quick scanning for busy staff; every empty state explains the next useful action.
- **Color philosophy:** warm parchment backgrounds reduce glare and make the product feel grounded; deep ink creates legible hierarchy; an ownable leaf-green marks action and healthy status; amber is reserved for attention, not decoration.
- **Layout paradigm:** a persistent left rail on desktop becomes a compact top bar and horizontal module strip on smaller screens. Content is organized as a narrative workspace—context header, key signal row, then an offset ledger/list—rather than a centered grid of equal cards.
- **Signature elements:** compact school crest mark; vertical green “signal” rule on active navigation and empty states; receipt-like data panels with hairline borders and inset labels.
- **Interaction philosophy:** actions are plain-language and local (“Add student”, “Record payment”), destructive actions require an explicit confirmation, and every save gives a visible toast plus optimistic loading state.
- **Animation:** subtle 160–220ms fades and slide-ins for panels; no looping motion; loading uses understated shimmer/spinner only where a request is pending.
- **Typography system:** Plus Jakarta Sans for UI/body with strong numeric tabular figures; Newsreader for page titles and editorial empty-state headings. Dense data uses 12–14px labels and 15–16px values.
- **Brand essence:** “The operating ledger for Ghanaian schools—clear enough for every classroom, rigorous enough for every account.” Personality: grounded, capable, humane.
- **Brand voice:** direct, warm and specific. Example lines: “Your school day, in one clear view.” “Nothing is invented here—your numbers begin at zero and grow with your records.”
- **Wordmark & logo:** a simple open book/crest monogram built from two angled leaves and a central ledger line, paired with the SmartSchool wordmark.
- **Signature brand color:** `#1F7A5A`, a grounded leaf-green that signals progress without looking like a banking product.

## Project structure

```text
smartschool/
├── client/src/
│   ├── components/          # shared UI and shell components
│   ├── contexts/             # theme and session context
│   ├── lib/                  # tRPC client and display helpers
│   ├── pages/                # route-level workspaces and portal pages
│   ├── App.tsx               # authenticated shell and route map
│   └── index.css             # design tokens and responsive styles
├── server/
│   ├── _core/                # starter OAuth, Express, tRPC context
│   ├── db.ts                 # Drizzle connection and feature queries
│   ├── permissions.ts        # role + tenant guards
│   ├── routers.ts            # typed feature API surface
│   └── storage.ts            # durable photo/asset upload helpers
├── drizzle/
│   ├── schema.ts             # relational schema
│   └── migrations/           # committed additive SQL migrations
├── public/manus-routes.json  # complete route manifest
├── plan.md                   # this architecture and design plan
├── TODO.md                   # outcome-oriented delivery checklist
└── README.md                 # local, VS Code and deployment instructions
```

## Implementation stages

1. **Foundation and shell:** document requirements, enable diagnostics, extend user model/tenant primitives, create route manifest, implement authenticated responsive shell, zero-state dashboard and settings entry points.
2. **People and academics:** add school setup, levels/classes/subjects/terms, student admissions with persistent photo references, staff profiles, guardians and membership management.
3. **Daily operations:** attendance, timetable conflict checks, announcements/messages, role-aware portals and audit trail.
4. **Money and assessment:** fee structures, charges, receipts, Ghana payment methods, guarded Paystack readiness, expenses, exams, grades and report-card exports.
5. **School services:** library circulation, assets/inventory, downloadable reports, branding and configuration refinements.
6. **Hardening and delivery:** server-side checks, type diagnostics, database migration review, workflow verification without seeding fake records, production build, checkpoint and deployment documentation.

## Local / VS Code / deployment workflow

- Install Node and pnpm 10.18, clone the canonical repository, run `pnpm install`, and provide the managed `DATABASE_URL` through the Manus environment rather than committing secrets.
- Run `pnpm db:migrate` for committed migrations, `pnpm dev` for the full app, `pnpm check` for TypeScript diagnostics and `pnpm test` for Vitest tests.
- In VS Code open the project root, use the integrated terminal for the same commands, and keep `.env` out of source control. Use the browser Preview for OAuth because redirect policy and the managed session are platform-owned.
- Deployment uses the committed Dockerfile and `/api/health`; the platform builds the app from the canonical checkpoint, injects runtime database/OAuth values, and retains database records across restarts.
