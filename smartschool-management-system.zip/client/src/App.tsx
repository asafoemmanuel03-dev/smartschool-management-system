import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";

const workspaceRoutes = [
  "/",
  "/students",
  "/staff",
  "/academics",
  "/attendance",
  "/finance",
  "/exams",
  "/timetable",
  "/library",
  "/communications",
  "/assets",
  "/reports",
  "/settings",
];

function Router() {
  return (
    <Switch>
      {workspaceRoutes.map(path => <Route key={path} path={path} component={Home} />)}
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster position="top-right" />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
