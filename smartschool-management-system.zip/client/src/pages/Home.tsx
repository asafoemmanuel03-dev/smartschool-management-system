import { useEffect, useMemo, useState } from "react";
import { useLocation } from "wouter";
import {
  ArrowUpRight,
  BarChart3,
  BookOpen,
  Building2,
  CalendarDays,
  Check,
  ChevronRight,
  CircleDollarSign,
  ClipboardCheck,
  GraduationCap,
  LayoutDashboard,
  Library,
  LogOut,
  Menu,
  MessageSquare,
  MoreHorizontal,
  Package,
  Plus,
  Search,
  Settings,
  ShieldCheck,
  Sparkles,
  Users,
  WalletCards,
  X,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { trpc } from "@/lib/trpc";

const navigation = [
  { href: "/", label: "Overview", icon: LayoutDashboard },
  { href: "/students", label: "Students", icon: GraduationCap },
  { href: "/staff", label: "Staff & roles", icon: Users },
  { href: "/academics", label: "Academics", icon: BookOpen },
  { href: "/attendance", label: "Attendance", icon: ClipboardCheck },
  { href: "/finance", label: "Fees & finance", icon: WalletCards },
  { href: "/exams", label: "Examinations", icon: BarChart3 },
  { href: "/timetable", label: "Timetable", icon: CalendarDays },
  { href: "/library", label: "Library", icon: Library },
  { href: "/communications", label: "Communications", icon: MessageSquare },
  { href: "/assets", label: "Assets", icon: Package },
  { href: "/reports", label: "Reports", icon: BarChart3 },
];

const roleLabels: Record<string, string> = {
  super_admin: "Super Administrator",
  school_admin: "School Administrator",
  headteacher: "Headteacher / Principal",
  accountant: "Accountant",
  teacher: "Teacher",
  student: "Student",
  parent: "Parent / Guardian",
  librarian: "Librarian",
};

type SchoolRecord = {
  id: number;
  name: string;
  code: string;
  slug: string;
  motto: string | null;
  phone: string | null;
  email: string | null;
  address: string | null;
  region: string | null;
  town: string | null;
  logoUrl: string | null;
  currency: string;
  status: "active" | "suspended";
  createdAt: Date;
  updatedAt: Date;
};

type SchoolContext = {
  school: SchoolRecord;
  membership: { role: string; status: string };
};

const moduleCopy: Record<string, { eyebrow: string; title: string; description: string; icon: typeof BookOpen; note: string }> = {
  "/staff": { eyebrow: "People directory", title: "Staff & roles", description: "Keep your teaching and support team in one trusted directory.", icon: Users, note: "Staff profiles, departments and role assignments are ready to be added after school setup." },
  "/academics": { eyebrow: "Academic structure", title: "Academics", description: "Shape the school year around the levels, classes and subjects you actually run.", icon: BookOpen, note: "Create levels, classes, departments, subjects and terms to make this workspace yours." },
  "/attendance": { eyebrow: "Daily rhythm", title: "Attendance", description: "A clear daily record for every class, without hand-counting later.", icon: ClipboardCheck, note: "Attendance sessions will appear here once classes and terms are configured." },
  "/finance": { eyebrow: "GHS ledger", title: "Fees & finance", description: "Record what comes in, what goes out and what still needs attention.", icon: CircleDollarSign, note: "No fees or payments have been recorded. Supported methods include cash, MTN Mobile Money, Telecel Cash, AT Money and bank transfer. Paystack stays disabled until securely verified." },
  "/exams": { eyebrow: "Assessment", title: "Examinations", description: "Turn marks into clear, publishable progress for families.", icon: BarChart3, note: "Exams and grades are empty by design. Add academic structure first, then create an assessment." },
  "/timetable": { eyebrow: "School day", title: "Timetable", description: "Build a timetable that respects class, teacher and room conflicts.", icon: CalendarDays, note: "No timetable entries yet. Conflict prevention will run when the first schedule is created." },
  "/library": { eyebrow: "Learning resources", title: "Library", description: "Know what is on the shelf, what is out and what is due back.", icon: Library, note: "The catalogue is empty. Add books and copies to begin circulation." },
  "/communications": { eyebrow: "Stay connected", title: "Communications", description: "Announcements and messages that reach the right school community.", icon: MessageSquare, note: "No announcements yet. School-wide messages will show here once published." },
  "/assets": { eyebrow: "School inventory", title: "Assets", description: "Keep an accountable record of the things your school relies on.", icon: Package, note: "No assets have been recorded. Add equipment, supplies and locations when you are ready." },
  "/reports": { eyebrow: "Evidence", title: "Reports", description: "Download useful views of the records your school has created.", icon: BarChart3, note: "Reports become available as students, attendance, finance and assessment records accumulate." },
};

function formatGhs(value: number) {
  return new Intl.NumberFormat("en-GH", { style: "currency", currency: "GHS", maximumFractionDigits: 0 }).format(value);
}

function initials(name?: string | null) {
  return (name || "SmartSchool").split(" ").map(part => part[0]).join("").slice(0, 2).toUpperCase();
}

function BrandMark({ compact = false }: { compact?: boolean }) {
  return (
    <div className="brand-lockup">
      <div className="brand-mark" aria-hidden="true"><span /><span /><i /></div>
      {!compact && <div><div className="brand-name">SmartSchool</div><div className="brand-subtitle">Ghana operations</div></div>}
    </div>
  );
}

function Field({ label, hint, ...props }: React.ComponentProps<typeof Input> & { label: string; hint?: string }) {
  return <label className="field"><span>{label}</span><Input {...props} />{hint && <small>{hint}</small>}</label>;
}

function EmptyState({ icon: Icon, title, description, action, onAction }: { icon: typeof BookOpen; title: string; description: string; action?: string; onAction?: () => void }) {
  return (
    <div className="empty-state">
      <div className="empty-icon"><Icon size={20} /></div>
      <div>
        <h3>{title}</h3>
        <p>{description}</p>
        {action && onAction && <Button variant="outline" size="sm" onClick={onAction}>{action}<ArrowUpRight size={15} /></Button>}
      </div>
    </div>
  );
}

function LoginLanding() {
  return (
    <main className="landing-page">
      <div className="landing-grain" />
      <header className="landing-header"><BrandMark /><Button variant="outline" onClick={startLogin}>Sign in <ArrowUpRight size={16} /></Button></header>
      <section className="landing-hero">
        <div className="hero-copy">
          <div className="eyebrow"><span className="eyebrow-dot" /> Built for Ghanaian schools</div>
          <h1>Your school day,<br /><em>in one clear view.</em></h1>
          <p>SmartSchool brings admissions, academics, people, attendance and finance into one calm operating ledger—without inventing a single number.</p>
          <div className="hero-actions"><Button size="lg" onClick={startLogin}>Enter your workspace <ArrowUpRight size={17} /></Button><span className="hero-note"><ShieldCheck size={16} /> Secure Manus account sign-in</span></div>
        </div>
        <div className="hero-card-wrap">
          <div className="hero-card-label">A clearer school office</div>
          <div className="hero-card">
            <div className="hero-card-top"><span>SmartSchool / Overview</span><MoreHorizontal size={16} /></div>
            <div className="hero-card-title">Good morning, school team.</div>
            <div className="mini-stat-row"><div><span>Students</span><strong>—</strong><small>Start with your records</small></div><div><span>Cash recorded</span><strong>GHS 0</strong><small>No payments yet</small></div></div>
            <div className="hero-ledger"><div className="ledger-line active" /><div className="ledger-line" /><div className="ledger-line short" /></div>
            <div className="hero-card-foot"><Sparkles size={15} /> Empty states that tell you what to do next.</div>
          </div>
        </div>
      </section>
      <div className="landing-footer"><span>Nursery · KG · Primary · JHS · SHS</span><span>GHS-first finance · Tenant-safe records · Mobile ready</span></div>
    </main>
  );
}

function Onboarding({ onCreated }: { onCreated: () => void }) {
  const [form, setForm] = useState({ name: "", code: "", motto: "", region: "", town: "" });
  const createSchool = trpc.school.create.useMutation({ onSuccess: () => { toast.success("School workspace created"); onCreated(); }, onError: error => toast.error(error.message) });
  return (
    <main className="onboarding-page">
      <div className="onboarding-card">
        <BrandMark />
        <div className="eyebrow"><span className="eyebrow-dot" /> First, make it yours</div>
        <h1>Set up your school workspace.</h1>
        <p className="lead">Your records will stay private to this school. You can add classes, people and terms after this first step.</p>
        <form onSubmit={event => { event.preventDefault(); createSchool.mutate(form); }} className="form-stack">
          <Field label="School name" placeholder="e.g. Adom Presbyterian School" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} required />
          <div className="form-grid"><Field label="School code" placeholder="ADOM-001" value={form.code} onChange={e => setForm({ ...form, code: e.target.value })} required /><Field label="Motto" placeholder="Optional" value={form.motto} onChange={e => setForm({ ...form, motto: e.target.value })} /></div>
          <div className="form-grid"><Field label="Region" placeholder="e.g. Greater Accra" value={form.region} onChange={e => setForm({ ...form, region: e.target.value })} /><Field label="Town / city" placeholder="e.g. Madina" value={form.town} onChange={e => setForm({ ...form, town: e.target.value })} /></div>
          <Button type="submit" size="lg" disabled={createSchool.isPending}>{createSchool.isPending ? "Creating workspace…" : "Create school workspace"}<ArrowUpRight size={17} /></Button>
        </form>
        <div className="security-note"><ShieldCheck size={16} /><span>Your account becomes the school administrator. You can invite other roles from the people directory.</span></div>
      </div>
    </main>
  );
}

function Sidebar({ path, schoolName, onClose }: { path: string; schoolName: string; onClose?: () => void }) {
  return <aside className="sidebar">
    <div className="sidebar-top"><BrandMark /><button className="mobile-close" onClick={onClose} aria-label="Close navigation"><X size={20} /></button></div>
    <div className="school-switcher"><div className="school-crest">{initials(schoolName)}</div><div><span>Current school</span><strong>{schoolName}</strong></div><ChevronRight size={15} /></div>
    <nav className="nav-list" aria-label="Main navigation">
      <div className="nav-label">Workspace</div>
      {navigation.slice(0, 5).map(item => <a key={item.href} href={item.href} onClick={onClose} className={path === item.href ? "nav-item active" : "nav-item"}><item.icon size={17} /><span>{item.label}</span>{path === item.href && <i />}</a>)}
      <div className="nav-label nav-label-spaced">Manage</div>
      {navigation.slice(5).map(item => <a key={item.href} href={item.href} onClick={onClose} className={path === item.href ? "nav-item active" : "nav-item"}><item.icon size={17} /><span>{item.label}</span>{path === item.href && <i />}</a>)}
    </nav>
    <div className="sidebar-bottom"><a href="/settings" onClick={onClose} className={path === "/settings" ? "nav-item active" : "nav-item"}><Settings size={17} /><span>School settings</span></a><div className="sidebar-meta">SmartSchool Ghana<br /><span>Secure school records</span></div></div>
  </aside>;
}

function Dashboard({ schoolName, onNavigate }: { schoolName: string; onNavigate: (href: string) => void }) {
  const dashboard = trpc.dashboard.useQuery();
  const data = dashboard.data;
  const cards = [
    { label: "Enrolled students", value: data ? data.counts.students.toString() : "—", detail: data?.counts.students ? "active records" : "Add your first admission", icon: GraduationCap, tone: "green" },
    { label: "Staff profiles", value: data ? data.counts.staff.toString() : "—", detail: data?.counts.staff ? "across the school" : "No staff records yet", icon: Users, tone: "ink" },
    { label: "Classes", value: data ? data.counts.classes.toString() : "—", detail: data?.counts.classes ? "configured groups" : "Set up academics", icon: BookOpen, tone: "amber" },
    { label: "Cash recorded", value: data ? formatGhs(data.finance.payments) : "—", detail: data?.finance.payments ? "verified receipts" : "No payments yet", icon: CircleDollarSign, tone: "blue" },
  ];
  return <>
    <PageHeader eyebrow="School overview" title={`Good morning, ${schoolName}.`} description="Your operating picture is derived from your records—nothing here is made up." action={<Button onClick={() => onNavigate("/students?action=new")}><Plus size={16} /> Add student</Button>} />
    <div className="signal-strip"><div><span className="signal-dot" /> Workspace is live</div><span>New schools start at zero. That is the point.</span></div>
    <section className="metric-grid">{cards.map(card => <div className={`metric-card ${card.tone}`} key={card.label}><div className="metric-top"><span>{card.label}</span><card.icon size={18} /></div><strong>{card.value}</strong><small>{card.detail}</small></div>)}</section>
    <section className="dashboard-grid">
      <Card className="ledger-card"><CardHeader><div><div className="card-kicker">First signals</div><CardTitle>Recent admissions</CardTitle></div><Button variant="ghost" size="sm" onClick={() => onNavigate("/students")}>View all <ChevronRight size={15} /></Button></CardHeader><CardContent>{data?.recentStudents?.length ? <div className="mini-table">{data.recentStudents.map(student => <div className="mini-row" key={student.id}><div className="student-avatar">{initials(student.name)}</div><div><strong>{student.name}</strong><span>{student.admissionNumber}</span></div><span className="status-pill">{student.status}</span></div>)}</div> : <EmptyState icon={GraduationCap} title="No admissions yet" description="When you add a learner, the latest record will appear here." action="Open admissions" onAction={() => onNavigate("/students?action=new")} />}</CardContent></Card>
      <Card className="ledger-card"><CardHeader><div><div className="card-kicker">School pulse</div><CardTitle>What needs attention</CardTitle></div><ShieldCheck size={18} className="header-icon" /></CardHeader><CardContent><div className="attention-list"><div className="attention-item"><div className="attention-icon green"><Building2 size={17} /></div><div><strong>Complete your academic setup</strong><span>Add levels, classes and subjects before daily operations.</span></div><button onClick={() => onNavigate("/academics")}><ArrowUpRight size={16} /></button></div><div className="attention-item"><div className="attention-icon amber"><Users size={17} /></div><div><strong>Bring in your school team</strong><span>Staff and role records make access safer and clearer.</span></div><button onClick={() => onNavigate("/staff")}><ArrowUpRight size={16} /></button></div><div className="attention-item"><div className="attention-icon blue"><Settings size={17} /></div><div><strong>Make the workspace yours</strong><span>Add contact details and your school’s public identity.</span></div><button onClick={() => onNavigate("/settings")}><ArrowUpRight size={16} /></button></div></div></CardContent></Card>
    </section>
    <div className="dashboard-footnote"><Sparkles size={16} /><span>SmartSchool keeps the first page quiet so your school’s real story can take its place.</span><button onClick={() => onNavigate("/reports")}>Explore reports <ArrowUpRight size={15} /></button></div>
  </>;
}

function StudentsPage({ onNavigate }: { onNavigate: (href: string) => void }) {
  const [location] = useLocation();
  const [search, setSearch] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [form, setForm] = useState({ admissionNumber: "", firstName: "", middleName: "", lastName: "", dateOfBirth: "", gender: "", phone: "", email: "", address: "", notes: "", photoData: "" });
  const students = trpc.students.list.useQuery({ search });
  const createStudent = trpc.students.create.useMutation({ onSuccess: () => { toast.success("Student admitted"); setDialogOpen(false); setForm({ admissionNumber: "", firstName: "", middleName: "", lastName: "", dateOfBirth: "", gender: "", phone: "", email: "", address: "", notes: "", photoData: "" }); void students.refetch(); }, onError: error => toast.error(error.message) });
  useEffect(() => { if (location.includes("action=new")) setDialogOpen(true); }, [location]);
  return <>
    <PageHeader eyebrow="Admissions & profiles" title="Students" description="A clean register for every learner your school serves." action={<Button onClick={() => setDialogOpen(true)}><Plus size={16} /> Add student</Button>} />
    <div className="page-toolbar"><div className="search-field"><Search size={17} /><Input placeholder="Search by name or admission number" value={search} onChange={e => setSearch(e.target.value)} /></div><span className="toolbar-count">{students.data?.length ?? 0} records</span></div>
    <Card className="data-card"><CardContent className="flush-card">{students.data?.length ? <div className="student-table"><div className="table-head"><span>Student</span><span>Admission no.</span><span>Contact</span><span>Status</span></div>{students.data.map(student => <div className="table-row" key={student.id}><div className="student-cell">{student.photoUrl ? <img className="student-photo" src={student.photoUrl} alt="" /> : <div className="student-avatar">{initials(`${student.firstName} ${student.lastName}`)}</div>}<div><strong>{student.firstName} {student.middleName ? `${student.middleName} ` : ""}{student.lastName}</strong><span>{student.gender || "Gender not set"}</span></div></div><span className="mono-text">{student.admissionNumber}</span><span className="muted-text">{student.phone || student.email || "No contact yet"}</span><span className="status-pill">{student.status}</span></div>)}</div> : <EmptyState icon={GraduationCap} title="Your admissions register is empty" description="Start with the learners already entrusted to your school. Each admission becomes a durable record, not a browser draft." action="Add first student" onAction={() => setDialogOpen(true)} />}</CardContent></Card>
    {dialogOpen && <div className="modal-backdrop" role="presentation" onMouseDown={event => { if (event.currentTarget === event.target) setDialogOpen(false); }}><div className="modal-card" role="dialog" aria-modal="true" aria-labelledby="admit-title"><div className="modal-header"><div><div className="card-kicker">New admission</div><h2 id="admit-title">Add a student</h2><p>The required fields create the register record. You can enrich the profile later.</p></div><button className="icon-button" onClick={() => setDialogOpen(false)} aria-label="Close"><X size={18} /></button></div><form className="form-stack" onSubmit={event => { event.preventDefault(); createStudent.mutate({ ...form, gender: (form.gender || undefined) as "female" | "male" | "other" | undefined, dateOfBirth: form.dateOfBirth || undefined, email: form.email || undefined, photoData: form.photoData || undefined }); }}><div className="form-grid"><Field label="Admission number" placeholder="e.g. SS-0001" value={form.admissionNumber} onChange={e => setForm({ ...form, admissionNumber: e.target.value })} required /><Field label="First name" placeholder="Ama" value={form.firstName} onChange={e => setForm({ ...form, firstName: e.target.value })} required /></div><div className="form-grid"><Field label="Middle name" placeholder="Optional" value={form.middleName} onChange={e => setForm({ ...form, middleName: e.target.value })} /><Field label="Last name" placeholder="Mensah" value={form.lastName} onChange={e => setForm({ ...form, lastName: e.target.value })} required /></div><div className="form-grid"><Field label="Date of birth" type="date" value={form.dateOfBirth} onChange={e => setForm({ ...form, dateOfBirth: e.target.value })} /><label className="field"><span>Gender</span><select value={form.gender} onChange={e => setForm({ ...form, gender: e.target.value })}><option value="">Not set</option><option value="female">Female</option><option value="male">Male</option><option value="other">Other</option></select></label></div><div className="form-grid"><Field label="Phone" placeholder="024…" value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} /><Field label="Email" type="email" placeholder="Optional" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} /></div><label className="photo-picker"><span>Profile photograph <small>Optional · PNG, JPEG or WebP up to 5MB</small></span><input type="file" accept="image/png,image/jpeg,image/webp" onChange={event => { const file = event.target.files?.[0]; if (!file) return; if (file.size > 5 * 1024 * 1024) { toast.error("Photo must be 5MB or smaller"); return; } const reader = new FileReader(); reader.onload = () => setForm({ ...form, photoData: String(reader.result) }); reader.readAsDataURL(file); }} />{form.photoData && <img src={form.photoData} alt="Selected profile preview" />}</label><Field label="Address" placeholder="Optional home address" value={form.address} onChange={e => setForm({ ...form, address: e.target.value })} /><div className="modal-actions"><Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button><Button type="submit" disabled={createStudent.isPending}>{createStudent.isPending ? "Saving…" : "Admit student"}<Check size={16} /></Button></div></form></div></div>}
  </>;
}

function SettingsPage({ school, role, onSaved }: { school: SchoolRecord; role: string; onSaved: () => void }) {
  const [form, setForm] = useState({ name: school.name, code: school.code, motto: school.motto || "", phone: school.phone || "", email: school.email || "", address: school.address || "", region: school.region || "", town: school.town || "" });
  const updateSchool = trpc.school.update.useMutation({ onSuccess: () => { toast.success("School settings saved"); onSaved(); }, onError: error => toast.error(error.message) });
  return <><PageHeader eyebrow="School identity" title="School settings" description="Keep the details on your workspace accurate and ready for reports." action={<Button onClick={() => updateSchool.mutate(form)} disabled={updateSchool.isPending}>{updateSchool.isPending ? "Saving…" : "Save changes"}<Check size={16} /></Button>} /><Card className="settings-card"><CardHeader><div className="card-kicker">Profile</div><CardTitle>School details</CardTitle></CardHeader><CardContent><div className="settings-section"><div className="settings-intro"><div className="school-crest large">{initials(school.name)}</div><div><strong>{school.name}</strong><p>These details belong to this school tenant and are not shared with any other school.</p></div></div><div className="form-grid"><Field label="School name" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} /><Field label="School code" value={form.code} onChange={e => setForm({ ...form, code: e.target.value })} /></div><div className="form-grid"><Field label="Motto" placeholder="Optional" value={form.motto} onChange={e => setForm({ ...form, motto: e.target.value })} /><Field label="Phone" placeholder="Optional" value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} /></div><div className="form-grid"><Field label="Email" type="email" placeholder="Optional" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} /><Field label="Region" placeholder="Optional" value={form.region} onChange={e => setForm({ ...form, region: e.target.value })} /></div><div className="form-grid"><Field label="Town / city" placeholder="Optional" value={form.town} onChange={e => setForm({ ...form, town: e.target.value })} /><Field label="Address" placeholder="Optional" value={form.address} onChange={e => setForm({ ...form, address: e.target.value })} /></div></div></CardContent></Card><Card className="settings-card"><CardHeader><div className="card-kicker">Security & access</div><CardTitle>Role policy</CardTitle></CardHeader><CardContent><div className="role-policy"><ShieldCheck size={19} /><div><strong>Tenant boundaries are enforced on the server.</strong><p>Your current role is <b>{roleLabels[role] || "School user"}</b>. Student, parent, teacher, accountant and librarian views will only expose records permitted by their school membership.</p></div></div></CardContent></Card></>;
}

function AcademicsPage() {
  const structure = trpc.academics.structure.useQuery();
  const [formMode, setFormMode] = useState<"level" | "class" | null>(null);
  const [levelForm, setLevelForm] = useState({ name: "", stage: "primary" });
  const [classForm, setClassForm] = useState({ name: "", code: "", levelId: "", capacity: "" });
  const refresh = () => void structure.refetch();
  const createLevel = trpc.academics.createLevel.useMutation({ onSuccess: () => { toast.success("Level added"); setFormMode(null); setLevelForm({ name: "", stage: "primary" }); refresh(); }, onError: error => toast.error(error.message) });
  const createClass = trpc.academics.createClass.useMutation({ onSuccess: () => { toast.success("Class added"); setFormMode(null); setClassForm({ name: "", code: "", levelId: "", capacity: "" }); refresh(); }, onError: error => toast.error(error.message) });
  return <><PageHeader eyebrow="Academic structure" title="Academics" description="Set the shape of your school before daily records begin." action={<div className="button-row"><Button variant="outline" onClick={() => setFormMode("level")}><Plus size={16} /> Add level</Button><Button onClick={() => setFormMode("class")}><Plus size={16} /> Add class</Button></div>} /><div className="setup-grid"><Card className="data-card"><CardHeader><div className="card-kicker">Learning stages</div><CardTitle>Levels</CardTitle></CardHeader><CardContent>{structure.data?.levels.length ? <div className="record-list">{structure.data.levels.map(level => <div className="record-row" key={level.id}><div><strong>{level.name}</strong><span>{level.stage}</span></div><span className="status-pill">active</span></div>)}</div> : <EmptyState icon={BookOpen} title="No levels yet" description="Add the stages your school operates, from nursery through SHS." action="Add level" onAction={() => setFormMode("level")} />}</CardContent></Card><Card className="data-card"><CardHeader><div className="card-kicker">Teaching groups</div><CardTitle>Classes</CardTitle></CardHeader><CardContent>{structure.data?.classes.length ? <div className="record-list">{structure.data.classes.map(item => <div className="record-row" key={item.id}><div><strong>{item.name}</strong><span>{item.code} · capacity {item.capacity || "not set"}</span></div><span className="status-pill">active</span></div>)}</div> : <EmptyState icon={Users} title="No classes yet" description="Add classes and streams so admissions and attendance have somewhere to land." action="Add class" onAction={() => setFormMode("class")} />}</CardContent></Card></div><Card className="data-card setup-summary"><CardHeader><div className="card-kicker">Structure at a glance</div><CardTitle>Ready for the next record</CardTitle></CardHeader><CardContent><div className="summary-strip"><div><strong>{structure.data?.levels.length ?? 0}</strong><span>levels</span></div><div><strong>{structure.data?.classes.length ?? 0}</strong><span>classes</span></div><div><strong>{structure.data?.subjects.length ?? 0}</strong><span>subjects</span></div><div><strong>{structure.data?.departments.length ?? 0}</strong><span>departments</span></div></div></CardContent></Card>{formMode && <div className="modal-backdrop" role="presentation" onMouseDown={event => { if (event.currentTarget === event.target) setFormMode(null); }}><div className="modal-card" role="dialog" aria-modal="true"><div className="modal-header"><div><div className="card-kicker">Academic setup</div><h2>{formMode === "level" ? "Add a level" : "Add a class"}</h2><p>These records are scoped to {"your school"} and can be used by later modules.</p></div><button className="icon-button" onClick={() => setFormMode(null)} aria-label="Close"><X size={18} /></button></div>{formMode === "level" ? <form className="form-stack" onSubmit={event => { event.preventDefault(); createLevel.mutate({ name: levelForm.name, stage: levelForm.stage as "nursery" | "kindergarten" | "primary" | "jhs" | "shs" }); }}><Field label="Level name" placeholder="e.g. Primary 1" value={levelForm.name} onChange={e => setLevelForm({ ...levelForm, name: e.target.value })} required /><label className="field"><span>Stage</span><select value={levelForm.stage} onChange={e => setLevelForm({ ...levelForm, stage: e.target.value })}><option value="nursery">Nursery</option><option value="kindergarten">Kindergarten</option><option value="primary">Primary</option><option value="jhs">JHS</option><option value="shs">SHS</option></select></label><div className="modal-actions"><Button type="button" variant="outline" onClick={() => setFormMode(null)}>Cancel</Button><Button type="submit" disabled={createLevel.isPending}>Save level <Check size={16} /></Button></div></form> : <form className="form-stack" onSubmit={event => { event.preventDefault(); createClass.mutate({ name: classForm.name, code: classForm.code, levelId: classForm.levelId ? Number(classForm.levelId) : undefined, capacity: classForm.capacity ? Number(classForm.capacity) : undefined }); }}><div className="form-grid"><Field label="Class name" placeholder="e.g. Primary 1A" value={classForm.name} onChange={e => setClassForm({ ...classForm, name: e.target.value })} required /><Field label="Class code" placeholder="P1-A" value={classForm.code} onChange={e => setClassForm({ ...classForm, code: e.target.value })} required /></div><div className="form-grid"><label className="field"><span>Level</span><select value={classForm.levelId} onChange={e => setClassForm({ ...classForm, levelId: e.target.value })}><option value="">Not assigned</option>{structure.data?.levels.map(level => <option value={level.id} key={level.id}>{level.name}</option>)}</select></label><Field label="Capacity" type="number" min="0" placeholder="Optional" value={classForm.capacity} onChange={e => setClassForm({ ...classForm, capacity: e.target.value })} /></div><div className="modal-actions"><Button type="button" variant="outline" onClick={() => setFormMode(null)}>Cancel</Button><Button type="submit" disabled={createClass.isPending}>Save class <Check size={16} /></Button></div></form>}</div></div>}</>;
}

function StaffPage() {
  const staff = trpc.staff.list.useQuery();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ staffNumber: "", firstName: "", lastName: "", jobTitle: "", phone: "", email: "" });
  const create = trpc.staff.create.useMutation({ onSuccess: () => { toast.success("Staff profile added"); setOpen(false); setForm({ staffNumber: "", firstName: "", lastName: "", jobTitle: "", phone: "", email: "" }); void staff.refetch(); }, onError: error => toast.error(error.message) });
  return <><PageHeader eyebrow="People directory" title="Staff & roles" description="Keep your teaching and support team in one trusted directory." action={<Button onClick={() => setOpen(true)}><Plus size={16} /> Add staff profile</Button>} /><Card className="data-card"><CardContent className="flush-card">{staff.data?.length ? <div className="student-table"><div className="table-head"><span>Staff member</span><span>Staff no.</span><span>Role</span><span>Status</span></div>{staff.data.map(item => <div className="table-row" key={item.id}><div className="student-cell"><div className="student-avatar">{initials(`${item.firstName} ${item.lastName}`)}</div><div><strong>{item.firstName} {item.lastName}</strong><span>{item.email || item.phone || "No contact yet"}</span></div></div><span className="mono-text">{item.staffNumber}</span><span className="muted-text">{item.jobTitle}</span><span className="status-pill">{item.employmentStatus.replace("_", " ")}</span></div>)}</div> : <EmptyState icon={Users} title="No staff profiles yet" description="Add the people who make your school run. Role invitations and permissions build on these records." action="Add first profile" onAction={() => setOpen(true)} />}</CardContent></Card>{open && <div className="modal-backdrop" role="presentation" onMouseDown={event => { if (event.currentTarget === event.target) setOpen(false); }}><div className="modal-card" role="dialog" aria-modal="true"><div className="modal-header"><div><div className="card-kicker">People directory</div><h2>Add staff profile</h2><p>Access roles can be connected after the profile is created.</p></div><button className="icon-button" onClick={() => setOpen(false)} aria-label="Close"><X size={18} /></button></div><form className="form-stack" onSubmit={event => { event.preventDefault(); create.mutate({ ...form, email: form.email || undefined }); }}><div className="form-grid"><Field label="Staff number" placeholder="ST-0001" value={form.staffNumber} onChange={e => setForm({ ...form, staffNumber: e.target.value })} required /><Field label="Job title" placeholder="Teacher" value={form.jobTitle} onChange={e => setForm({ ...form, jobTitle: e.target.value })} required /></div><div className="form-grid"><Field label="First name" placeholder="Akosua" value={form.firstName} onChange={e => setForm({ ...form, firstName: e.target.value })} required /><Field label="Last name" placeholder="Owusu" value={form.lastName} onChange={e => setForm({ ...form, lastName: e.target.value })} required /></div><div className="form-grid"><Field label="Phone" placeholder="Optional" value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} /><Field label="Email" type="email" placeholder="Optional" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} /></div><div className="modal-actions"><Button type="button" variant="outline" onClick={() => setOpen(false)}>Cancel</Button><Button type="submit" disabled={create.isPending}>Save profile <Check size={16} /></Button></div></form></div></div>}</>;
}

function FinancePage() {
  const payments = trpc.finance.payments.useQuery();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ receiptNumber: "", amount: "", method: "cash", providerReference: "" });
  const record = trpc.finance.recordPayment.useMutation({ onSuccess: () => { toast.success("Payment recorded"); setOpen(false); setForm({ receiptNumber: "", amount: "", method: "cash", providerReference: "" }); void payments.refetch(); }, onError: error => toast.error(error.message) });
  const total = payments.data?.reduce((sum, item) => sum + Number(item.amount), 0) || 0;
  return <><PageHeader eyebrow="GHS ledger" title="Fees & finance" description="Record what comes in, what goes out and what still needs attention." action={<Button onClick={() => setOpen(true)}><Plus size={16} /> Record payment</Button>} /><div className="metric-grid finance-metrics"><div className="metric-card green"><div className="metric-top"><span>Verified receipts</span><Check size={17} /></div><strong>{payments.data?.length ?? 0}</strong><small>database-backed entries</small></div><div className="metric-card blue"><div className="metric-top"><span>Cash recorded</span><CircleDollarSign size={17} /></div><strong>{formatGhs(total)}</strong><small>verified payments only</small></div><div className="metric-card amber"><div className="metric-top"><span>Paystack</span><ShieldCheck size={17} /></div><strong>Off</strong><small>secure verification required</small></div></div><Card className="data-card"><CardHeader><div className="card-kicker">Receipts</div><CardTitle>Recent payments</CardTitle></CardHeader><CardContent className="flush-card">{payments.data?.length ? <div className="student-table"><div className="table-head"><span>Receipt</span><span>Amount</span><span>Method</span><span>Status</span></div>{payments.data.map(payment => <div className="table-row" key={payment.id}><span className="mono-text">{payment.receiptNumber}</span><strong>{formatGhs(Number(payment.amount))}</strong><span className="muted-text">{payment.method.replaceAll("_", " ")}</span><span className="status-pill">{payment.status}</span></div>)}</div> : <EmptyState icon={WalletCards} title="No payments recorded" description="A clean finance ledger starts at GHS 0. Record a verified cash or mobile-money receipt when you are ready." action="Record first payment" onAction={() => setOpen(true)} />}</CardContent></Card>{open && <div className="modal-backdrop" role="presentation" onMouseDown={event => { if (event.currentTarget === event.target) setOpen(false); }}><div className="modal-card" role="dialog" aria-modal="true"><div className="modal-header"><div><div className="card-kicker">Verified receipt</div><h2>Record a payment</h2><p>Paystack is deliberately unavailable until its server-side verification is complete.</p></div><button className="icon-button" onClick={() => setOpen(false)} aria-label="Close"><X size={18} /></button></div><form className="form-stack" onSubmit={event => { event.preventDefault(); record.mutate({ ...form, method: form.method as "cash" | "mtn_momo" | "telecel_cash" | "at_money" | "bank_transfer", providerReference: form.providerReference || undefined }); }}><div className="form-grid"><Field label="Receipt number" placeholder="RCPT-0001" value={form.receiptNumber} onChange={e => setForm({ ...form, receiptNumber: e.target.value })} required /><Field label="Amount (GHS)" type="number" min="0.01" step="0.01" placeholder="0.00" value={form.amount} onChange={e => setForm({ ...form, amount: e.target.value })} required /></div><label className="field"><span>Payment method</span><select value={form.method} onChange={e => setForm({ ...form, method: e.target.value })}><option value="cash">Cash</option><option value="mtn_momo">MTN Mobile Money</option><option value="telecel_cash">Telecel Cash</option><option value="at_money">AT Money</option><option value="bank_transfer">Bank transfer</option></select></label><Field label="Provider reference" placeholder="Optional transaction reference" value={form.providerReference} onChange={e => setForm({ ...form, providerReference: e.target.value })} /><div className="modal-actions"><Button type="button" variant="outline" onClick={() => setOpen(false)}>Cancel</Button><Button type="submit" disabled={record.isPending}>Save receipt <Check size={16} /></Button></div></form></div></div>}</>;
}

function CommunicationsPage() {
  const announcements = trpc.communications.list.useQuery();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ title: "", body: "", audience: "all" });
  const publish = trpc.communications.publish.useMutation({ onSuccess: () => { toast.success("Announcement published"); setOpen(false); setForm({ title: "", body: "", audience: "all" }); void announcements.refetch(); }, onError: error => toast.error(error.message) });
  return <><PageHeader eyebrow="Stay connected" title="Communications" description="Announcements and messages that reach the right school community." action={<Button onClick={() => setOpen(true)}><Plus size={16} /> New announcement</Button>} /><Card className="data-card"><CardContent className="flush-card">{announcements.data?.length ? <div className="announcement-list">{announcements.data.map(item => <article className="announcement-row" key={item.id}><div className="announcement-mark"><MessageSquare size={17} /></div><div><div className="announcement-meta">{item.audience} · {item.publishedAt ? new Date(item.publishedAt).toLocaleDateString("en-GH") : "published"}</div><h3>{item.title}</h3><p>{item.body}</p></div></article>)}</div> : <EmptyState icon={MessageSquare} title="No announcements yet" description="Keep families and staff in the loop with a clear, audience-aware message." action="Publish first announcement" onAction={() => setOpen(true)} />}</CardContent></Card>{open && <div className="modal-backdrop" role="presentation" onMouseDown={event => { if (event.currentTarget === event.target) setOpen(false); }}><div className="modal-card" role="dialog" aria-modal="true"><div className="modal-header"><div><div className="card-kicker">Communication centre</div><h2>New announcement</h2><p>Published messages appear to the selected audience.</p></div><button className="icon-button" onClick={() => setOpen(false)} aria-label="Close"><X size={18} /></button></div><form className="form-stack" onSubmit={event => { event.preventDefault(); publish.mutate({ ...form, audience: form.audience as "all" | "staff" | "students" | "parents" }); }}><Field label="Title" placeholder="e.g. Mid-term break reminder" value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} required /><label className="field"><span>Audience</span><select value={form.audience} onChange={e => setForm({ ...form, audience: e.target.value })}><option value="all">Everyone</option><option value="staff">Staff</option><option value="students">Students</option><option value="parents">Parents / guardians</option></select></label><label className="field"><span>Message</span><textarea className="text-area" rows={5} placeholder="Write the announcement" value={form.body} onChange={e => setForm({ ...form, body: e.target.value })} required /></label><div className="modal-actions"><Button type="button" variant="outline" onClick={() => setOpen(false)}>Cancel</Button><Button type="submit" disabled={publish.isPending}>Publish announcement <ArrowUpRight size={16} /></Button></div></form></div></div>}</>;
}

function AttendancePage() {
  const sessions = trpc.attendance.list.useQuery();
  const structure = trpc.academics.structure.useQuery();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ classId: "", date: new Date().toISOString().slice(0, 10) });
  const create = trpc.attendance.createSession.useMutation({ onSuccess: () => { toast.success("Attendance session created"); setOpen(false); void sessions.refetch(); }, onError: error => toast.error(error.message) });
  return <><PageHeader eyebrow="Daily rhythm" title="Attendance" description="Create one clear attendance session for each class and date." action={<Button onClick={() => setOpen(true)} disabled={!structure.data?.classes.length}><Plus size={16} /> New session</Button>} /><Card className="data-card"><CardHeader><div className="card-kicker">Attendance register</div><CardTitle>Sessions</CardTitle></CardHeader><CardContent>{sessions.data?.length ? <div className="record-list">{sessions.data.map(session => <div className="record-row" key={session.id}><div><strong>{structure.data?.classes.find(item => item.id === session.classId)?.name || `Class #${session.classId}`}</strong><span>{new Date(session.date).toLocaleDateString("en-GH")} · {session.status}</span></div><span className="status-pill">{session.status}</span></div>)}</div> : <EmptyState icon={ClipboardCheck} title="No attendance sessions yet" description={structure.data?.classes.length ? "Start a daily register for one of your classes." : "Add a class in Academics before starting attendance."} action={structure.data?.classes.length ? "Create first session" : "Open academics"} onAction={() => structure.data?.classes.length ? setOpen(true) : window.location.assign("/academics")} />}</CardContent></Card>{open && <div className="modal-backdrop" role="presentation" onMouseDown={event => { if (event.currentTarget === event.target) setOpen(false); }}><div className="modal-card" role="dialog" aria-modal="true"><div className="modal-header"><div><div className="card-kicker">Daily register</div><h2>New attendance session</h2><p>One session per class and date keeps the record unambiguous.</p></div><button className="icon-button" onClick={() => setOpen(false)} aria-label="Close"><X size={18} /></button></div><form className="form-stack" onSubmit={event => { event.preventDefault(); create.mutate({ classId: Number(form.classId), date: new Date(form.date) }); }}><label className="field"><span>Class</span><select value={form.classId} onChange={e => setForm({ ...form, classId: e.target.value })} required><option value="">Select a class</option>{structure.data?.classes.map(item => <option value={item.id} key={item.id}>{item.name} · {item.code}</option>)}</select></label><Field label="Date" type="date" value={form.date} onChange={e => setForm({ ...form, date: e.target.value })} required /><div className="modal-actions"><Button type="button" variant="outline" onClick={() => setOpen(false)}>Cancel</Button><Button type="submit" disabled={create.isPending}>Create session <Check size={16} /></Button></div></form></div></div>}</>;
}

function TimetablePage() {
  const entries = trpc.timetable.list.useQuery();
  const structure = trpc.academics.structure.useQuery();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ classId: "", subjectLabel: "", teacherLabel: "", weekday: "monday", startTime: "08:00", endTime: "09:00", room: "" });
  const create = trpc.timetable.create.useMutation({ onSuccess: () => { toast.success("Timetable entry added"); setOpen(false); void entries.refetch(); }, onError: error => toast.error(error.message) });
  return <><PageHeader eyebrow="School day" title="Timetable" description="Build a timetable that respects class and room conflicts." action={<Button onClick={() => setOpen(true)}><Plus size={16} /> Add entry</Button>} /><Card className="data-card"><CardHeader><div className="card-kicker">Weekly view</div><CardTitle>Timetable entries</CardTitle></CardHeader><CardContent>{entries.data?.length ? <div className="record-list">{entries.data.map(entry => <div className="record-row" key={entry.id}><div><strong>{entry.subjectLabel}</strong><span>{entry.weekday} · {entry.startTime}–{entry.endTime} · {entry.teacherLabel || "Teacher not set"}</span></div><span className="status-pill">{entry.room || "Room open"}</span></div>)}</div> : <EmptyState icon={CalendarDays} title="No timetable entries yet" description="Add the first lesson. The server will reject overlapping class or room bookings." action="Add first entry" onAction={() => setOpen(true)} />}</CardContent></Card>{open && <div className="modal-backdrop" role="presentation" onMouseDown={event => { if (event.currentTarget === event.target) setOpen(false); }}><div className="modal-card" role="dialog" aria-modal="true"><div className="modal-header"><div><div className="card-kicker">Weekly schedule</div><h2>Add timetable entry</h2><p>Conflict checks run against existing entries in this school.</p></div><button className="icon-button" onClick={() => setOpen(false)} aria-label="Close"><X size={18} /></button></div><form className="form-stack" onSubmit={event => { event.preventDefault(); create.mutate({ ...form, classId: form.classId ? Number(form.classId) : undefined, weekday: form.weekday as "monday" | "tuesday" | "wednesday" | "thursday" | "friday" | "saturday", teacherLabel: form.teacherLabel || undefined, room: form.room || undefined }); }}><div className="form-grid"><label className="field"><span>Class</span><select value={form.classId} onChange={e => setForm({ ...form, classId: e.target.value })}><option value="">All-school / not assigned</option>{structure.data?.classes.map(item => <option value={item.id} key={item.id}>{item.name}</option>)}</select></label><Field label="Subject" placeholder="Mathematics" value={form.subjectLabel} onChange={e => setForm({ ...form, subjectLabel: e.target.value })} required /></div><div className="form-grid"><label className="field"><span>Day</span><select value={form.weekday} onChange={e => setForm({ ...form, weekday: e.target.value })}><option value="monday">Monday</option><option value="tuesday">Tuesday</option><option value="wednesday">Wednesday</option><option value="thursday">Thursday</option><option value="friday">Friday</option><option value="saturday">Saturday</option></select></label><Field label="Teacher" placeholder="Optional" value={form.teacherLabel} onChange={e => setForm({ ...form, teacherLabel: e.target.value })} /></div><div className="form-grid"><Field label="Start" type="time" value={form.startTime} onChange={e => setForm({ ...form, startTime: e.target.value })} /><Field label="End" type="time" value={form.endTime} onChange={e => setForm({ ...form, endTime: e.target.value })} /></div><Field label="Room" placeholder="Optional room or venue" value={form.room} onChange={e => setForm({ ...form, room: e.target.value })} /><div className="modal-actions"><Button type="button" variant="outline" onClick={() => setOpen(false)}>Cancel</Button><Button type="submit" disabled={create.isPending}>Save entry <Check size={16} /></Button></div></form></div></div>}</>;
}

function ExamsPage() {
  const exams = trpc.exams.list.useQuery();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ title: "", type: "End of term", startsOn: new Date().toISOString().slice(0, 10), endsOn: "" });
  const create = trpc.exams.create.useMutation({ onSuccess: () => { toast.success("Exam created"); setOpen(false); void exams.refetch(); }, onError: error => toast.error(error.message) });
  return <><PageHeader eyebrow="Assessment" title="Examinations" description="Create an assessment calendar before entering marks and report cards." action={<Button onClick={() => setOpen(true)}><Plus size={16} /> Create exam</Button>} /><Card className="data-card"><CardHeader><div className="card-kicker">Assessment calendar</div><CardTitle>Exams</CardTitle></CardHeader><CardContent>{exams.data?.length ? <div className="record-list">{exams.data.map(item => <div className="record-row" key={item.id}><div><strong>{item.title}</strong><span>{item.type} · {new Date(item.startsOn).toLocaleDateString("en-GH")}</span></div><span className="status-pill">{item.status}</span></div>)}</div> : <EmptyState icon={BarChart3} title="No exams created" description="Keep assessment records empty until your school is ready to schedule one." action="Create first exam" onAction={() => setOpen(true)} />}</CardContent></Card>{open && <div className="modal-backdrop" role="presentation" onMouseDown={event => { if (event.currentTarget === event.target) setOpen(false); }}><div className="modal-card" role="dialog" aria-modal="true"><div className="modal-header"><div><div className="card-kicker">Assessment setup</div><h2>Create an exam</h2><p>Marks and report cards can be connected in the next assessment step.</p></div><button className="icon-button" onClick={() => setOpen(false)} aria-label="Close"><X size={18} /></button></div><form className="form-stack" onSubmit={event => { event.preventDefault(); create.mutate({ title: form.title, type: form.type, startsOn: new Date(form.startsOn), endsOn: form.endsOn ? new Date(form.endsOn) : undefined }); }}><div className="form-grid"><Field label="Exam title" placeholder="e.g. First term assessment" value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} required /><Field label="Type" placeholder="End of term" value={form.type} onChange={e => setForm({ ...form, type: e.target.value })} required /></div><div className="form-grid"><Field label="Starts" type="date" value={form.startsOn} onChange={e => setForm({ ...form, startsOn: e.target.value })} required /><Field label="Ends" type="date" value={form.endsOn} onChange={e => setForm({ ...form, endsOn: e.target.value })} /></div><div className="modal-actions"><Button type="button" variant="outline" onClick={() => setOpen(false)}>Cancel</Button><Button type="submit" disabled={create.isPending}>Save exam <Check size={16} /></Button></div></form></div></div>}</>;
}

function LibraryPage() {
  const books = trpc.library.list.useQuery();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ title: "", author: "", category: "", totalCopies: "1", shelf: "", isbn: "" });
  const create = trpc.library.create.useMutation({ onSuccess: () => { toast.success("Book added"); setOpen(false); void books.refetch(); }, onError: error => toast.error(error.message) });
  return <><PageHeader eyebrow="Learning resources" title="Library" description="Know what is on the shelf and how many copies are available." action={<Button onClick={() => setOpen(true)}><Plus size={16} /> Add book</Button>} /><Card className="data-card"><CardHeader><div className="card-kicker">Catalogue</div><CardTitle>Books</CardTitle></CardHeader><CardContent>{books.data?.length ? <div className="record-list">{books.data.map(book => <div className="record-row" key={book.id}><div><strong>{book.title}</strong><span>{book.author || "Author not set"} · {book.category || "Uncategorised"}</span></div><span className="status-pill">{book.availableCopies}/{book.totalCopies} available</span></div>)}</div> : <EmptyState icon={Library} title="The catalogue is empty" description="Add the books already in your school library. Availability starts from the number of copies you enter." action="Add first book" onAction={() => setOpen(true)} />}</CardContent></Card>{open && <div className="modal-backdrop" role="presentation" onMouseDown={event => { if (event.currentTarget === event.target) setOpen(false); }}><div className="modal-card" role="dialog" aria-modal="true"><div className="modal-header"><div><div className="card-kicker">Library catalogue</div><h2>Add a book</h2><p>Borrowing and returns will use these available-copy counts.</p></div><button className="icon-button" onClick={() => setOpen(false)} aria-label="Close"><X size={18} /></button></div><form className="form-stack" onSubmit={event => { event.preventDefault(); create.mutate({ ...form, totalCopies: Number(form.totalCopies), author: form.author || undefined, category: form.category || undefined, shelf: form.shelf || undefined, isbn: form.isbn || undefined }); }}><Field label="Title" placeholder="Book title" value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} required /><div className="form-grid"><Field label="Author" placeholder="Optional" value={form.author} onChange={e => setForm({ ...form, author: e.target.value })} /><Field label="Category" placeholder="Optional" value={form.category} onChange={e => setForm({ ...form, category: e.target.value })} /></div><div className="form-grid"><Field label="Copies" type="number" min="1" value={form.totalCopies} onChange={e => setForm({ ...form, totalCopies: e.target.value })} required /><Field label="Shelf" placeholder="Optional" value={form.shelf} onChange={e => setForm({ ...form, shelf: e.target.value })} /></div><div className="modal-actions"><Button type="button" variant="outline" onClick={() => setOpen(false)}>Cancel</Button><Button type="submit" disabled={create.isPending}>Save book <Check size={16} /></Button></div></form></div></div>}</>;
}

function AssetsPage() {
  const assets = trpc.assets.list.useQuery();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ assetTag: "", name: "", category: "", quantity: "1", condition: "", location: "" });
  const create = trpc.assets.create.useMutation({ onSuccess: () => { toast.success("Asset added"); setOpen(false); void assets.refetch(); }, onError: error => toast.error(error.message) });
  return <><PageHeader eyebrow="School inventory" title="Assets" description="Keep an accountable record of the things your school relies on." action={<Button onClick={() => setOpen(true)}><Plus size={16} /> Add asset</Button>} /><Card className="data-card"><CardHeader><div className="card-kicker">Inventory register</div><CardTitle>Assets</CardTitle></CardHeader><CardContent>{assets.data?.length ? <div className="record-list">{assets.data.map(item => <div className="record-row" key={item.id}><div><strong>{item.name}</strong><span>{item.assetTag} · {item.location || "Location not set"} · {item.condition || "Condition not set"}</span></div><span className="status-pill">{item.quantity} unit{item.quantity === 1 ? "" : "s"}</span></div>)}</div> : <EmptyState icon={Package} title="No assets recorded" description="Start a reliable inventory with the equipment and supplies your school already owns." action="Add first asset" onAction={() => setOpen(true)} />}</CardContent></Card>{open && <div className="modal-backdrop" role="presentation" onMouseDown={event => { if (event.currentTarget === event.target) setOpen(false); }}><div className="modal-card" role="dialog" aria-modal="true"><div className="modal-header"><div><div className="card-kicker">Inventory register</div><h2>Add an asset</h2><p>Asset tags stay unique within this school.</p></div><button className="icon-button" onClick={() => setOpen(false)} aria-label="Close"><X size={18} /></button></div><form className="form-stack" onSubmit={event => { event.preventDefault(); create.mutate({ ...form, quantity: Number(form.quantity), category: form.category || undefined, condition: form.condition || undefined, location: form.location || undefined }); }}><div className="form-grid"><Field label="Asset tag" placeholder="AST-0001" value={form.assetTag} onChange={e => setForm({ ...form, assetTag: e.target.value })} required /><Field label="Asset name" placeholder="Projector" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} required /></div><div className="form-grid"><Field label="Category" placeholder="Optional" value={form.category} onChange={e => setForm({ ...form, category: e.target.value })} /><Field label="Quantity" type="number" min="1" value={form.quantity} onChange={e => setForm({ ...form, quantity: e.target.value })} required /></div><div className="form-grid"><Field label="Condition" placeholder="Good" value={form.condition} onChange={e => setForm({ ...form, condition: e.target.value })} /><Field label="Location" placeholder="Optional" value={form.location} onChange={e => setForm({ ...form, location: e.target.value })} /></div><div className="modal-actions"><Button type="button" variant="outline" onClick={() => setOpen(false)}>Cancel</Button><Button type="submit" disabled={create.isPending}>Save asset <Check size={16} /></Button></div></form></div></div>}</>;
}

function ReportsPage() {
  const students = trpc.students.list.useQuery({ search: "" });
  const payments = trpc.finance.payments.useQuery();
  const download = (kind: "students" | "payments") => {
    const rows = kind === "students" ? [["Admission number", "First name", "Last name", "Status"], ...(students.data || []).map(item => [item.admissionNumber, item.firstName, item.lastName, item.status])] : [["Receipt", "Amount GHS", "Method", "Status"], ...(payments.data || []).map(item => [item.receiptNumber, item.amount, item.method, item.status])];
    const csv = rows.map(row => row.map(value => `"${String(value).replaceAll('"', '""')}"`).join(",")).join("\n");
    const url = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" }));
    const link = document.createElement("a"); link.href = url; link.download = `smartschool-${kind}.csv`; link.click(); URL.revokeObjectURL(url); toast.success("Report downloaded");
  };
  return <><PageHeader eyebrow="Evidence" title="Reports" description="Download useful views of the records your school has actually created." /><div className="setup-grid"><Card className="data-card"><CardContent><div className="module-hero-icon"><GraduationCap size={23} /></div><h2 className="report-title">Admissions register</h2><p className="report-description">A CSV export of current student admissions, with no invented rows.</p><Button variant="outline" onClick={() => download("students")} disabled={!students.data}><ArrowUpRight size={16} /> Download CSV</Button></CardContent></Card><Card className="data-card"><CardContent><div className="module-hero-icon"><CircleDollarSign size={23} /></div><h2 className="report-title">Payment ledger</h2><p className="report-description">A CSV export of verified receipts recorded in this school.</p><Button variant="outline" onClick={() => download("payments")} disabled={!payments.data}><ArrowUpRight size={16} /> Download CSV</Button></CardContent></Card></div><div className="module-note-row"><ShieldCheck size={16} /><span>Exports are created from the active school tenant in your browser and contain only records returned by protected APIs.</span></div></>;
}

function ModulePage({ path, onNavigate }: { path: string; onNavigate: (href: string) => void }) {
  const content = moduleCopy[path];
  const Icon = content.icon;
  return <><PageHeader eyebrow={content.eyebrow} title={content.title} description={content.description} action={<Button variant="outline" onClick={() => onNavigate("/settings")}><Settings size={16} /> Open settings</Button>} /><Card className="module-empty-card"><CardContent><div className="module-hero-icon"><Icon size={25} /></div><h2>{content.title} is ready for your records.</h2><p>{content.note}</p><div className="module-actions"><Button onClick={() => onNavigate("/settings")}>Configure school workspace <ArrowUpRight size={16} /></Button><Button variant="ghost" onClick={() => onNavigate("/")}>Back to overview</Button></div></CardContent></Card><div className="module-note-row"><ShieldCheck size={16} /><span>Nothing is pre-filled. SmartSchool only reports what your school has actually created.</span></div></>;
}

function PageHeader({ eyebrow, title, description, action }: { eyebrow: string; title: string; description: string; action?: React.ReactNode }) {
  return <div className="page-header"><div><div className="eyebrow"><span className="eyebrow-dot" /> {eyebrow}</div><h1>{title}</h1><p>{description}</p></div>{action && <div className="page-header-action">{action}</div>}</div>;
}

function Workspace({ schoolContext, user, onLogout }: { schoolContext: SchoolContext; user: { name: string | null; email: string | null }; onLogout: () => void }) {
  const [location, setLocation] = useLocation();
  const [mobileMenu, setMobileMenu] = useState(false);
  const path = location.split("?")[0] || "/";
  const school = schoolContext.school;
  const utils = trpc.useUtils();
  const page = path === "/" ? <Dashboard schoolName={school.name} onNavigate={href => setLocation(href)} /> : path === "/students" ? <StudentsPage onNavigate={href => setLocation(href)} /> : path === "/academics" ? <AcademicsPage /> : path === "/staff" ? <StaffPage /> : path === "/finance" ? <FinancePage /> : path === "/communications" ? <CommunicationsPage /> : path === "/attendance" ? <AttendancePage /> : path === "/timetable" ? <TimetablePage /> : path === "/exams" ? <ExamsPage /> : path === "/library" ? <LibraryPage /> : path === "/assets" ? <AssetsPage /> : path === "/reports" ? <ReportsPage /> : path === "/settings" ? <SettingsPage school={school} role={schoolContext.membership.role} onSaved={() => void utils.school.context.invalidate()} /> : <ModulePage path={path} onNavigate={href => setLocation(href)} />;
  return <div className="app-shell"><div className={mobileMenu ? "mobile-scrim open" : "mobile-scrim"} onClick={() => setMobileMenu(false)} /> <div className={mobileMenu ? "sidebar-mobile open" : "sidebar-mobile"}><Sidebar path={path} schoolName={school.name} onClose={() => setMobileMenu(false)} /></div><div className="desktop-sidebar"><Sidebar path={path} schoolName={school.name} /></div><div className="main-column"><header className="topbar"><button className="menu-button" onClick={() => setMobileMenu(true)} aria-label="Open navigation"><Menu size={20} /></button><div className="topbar-context"><span>{school.name}</span><b>/</b><strong>{path === "/" ? "Overview" : navigation.find(item => item.href === path)?.label || "Settings"}</strong></div><div className="topbar-actions"><button className="topbar-icon" onClick={() => setLocation("/communications")} aria-label="Open communications"><MessageSquare size={18} /></button><div className="user-menu"><div className="user-avatar">{initials(user.name)}</div><div className="user-details"><strong>{user.name || "Account owner"}</strong><span>{roleLabels[schoolContext.membership.role] || "School user"}</span></div><button className="logout-button" onClick={onLogout} aria-label="Sign out"><LogOut size={16} /></button></div></div></header><main className="content-wrap">{page}</main><footer className="app-footer"><span>SmartSchool Ghana</span><span>Private school workspace · {new Date().getFullYear()}</span></footer></div></div>;
}

export default function Home() {
  const auth = useAuth();
  const schoolContext = trpc.school.context.useQuery(undefined, { enabled: auth.isAuthenticated, retry: false });
  const utils = trpc.useUtils();
  const [loadingOut, setLoadingOut] = useState(false);
  if (auth.loading || (auth.isAuthenticated && schoolContext.isLoading)) return <div className="loading-screen"><BrandMark /><div className="loading-line" /><p>Preparing your school workspace…</p></div>;
  if (!auth.isAuthenticated) return <LoginLanding />;
  if (!schoolContext.data) return <Onboarding onCreated={() => { void schoolContext.refetch(); }} />;
  return <Workspace schoolContext={schoolContext.data} user={auth.user!} onLogout={async () => { setLoadingOut(true); try { await auth.logout(); } finally { setLoadingOut(false); } }} />;
}
