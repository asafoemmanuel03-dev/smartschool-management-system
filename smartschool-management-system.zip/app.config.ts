export default {
  logoUrl: "https://dummyimage.com/256x256/1f7a5a/ffffff.png&text=SS",
};
