# SmartSchool Ghana System Documentation

**Document version:** 1.1  
**System:** SmartSchool Ghana  
**Project type:** Multi-school school management and operations platform  
**Primary audience:** School owners, administrators, headteachers, accountants, teachers, librarians, developers and deployment operators

---

## Abstract

SmartSchool Ghana is a multi-school management and e-commerce-ready operations platform designed for Ghanaian schools from nursery through SHS. It brings school administration, admissions, academic setup, attendance, finance, communication, examinations, timetables, library resources, inventory and reporting into one secure, mobile-responsive workspace.

The system uses Manus OAuth for identity, role-based permissions for different school actors, tenant-scoped data access for school separation, managed MySQL for durable business records and managed object storage for student photographs and other files. Its most important data principle is that the platform never invents operational history: new-school metrics, payments, attendance, exams and other statistics begin at zero and change only when authorized users create real records.

This document describes the system purpose, inspiration, current functionality, operating procedures, technical architecture, database design, security model, development workflow, deployment process and planned extensions.

## Project inspiration and rationale

SmartSchool was inspired by the practical need for a single, dependable operating record for schools whose daily work is often spread across paper registers, spreadsheets, messaging groups, notebooks and separate payment channels. That fragmentation makes it difficult to answer basic operational questions quickly: which learners are admitted, which classes exist, what has been paid, which lessons are scheduled, what resources are available and which information can a particular staff member access?

The project is especially shaped by the Ghanaian school context:

- Schools may serve several educational stages, from nursery and kindergarten through primary, JHS and SHS.
- Finance workflows need to recognize cash, MTN Mobile Money, Telecel Cash, AT Money and bank transfers.
- School teams need a system that works comfortably on mobile devices as well as desktop computers.
- Administrators need trustworthy numbers rather than dashboards populated with fictional demo data.
- Parents, teachers, accountants, librarians and school leaders need different views of the same school without crossing access boundaries.
- Student photographs and administrative files need durable storage rather than temporary browser URLs.

The product direction therefore combines a calm civic-service interface with strong operational discipline: simple actions, clear empty states, persistent records, tenant isolation and server-side authorization. SmartSchool is intended to become a dependable school ledger that grows from the school's own records instead of asking staff to reconcile several disconnected systems.

## Table of contents

1. [Abstract](#abstract)
2. [Project inspiration and rationale](#project-inspiration-and-rationale)
3. [System overview](#1-system-overview)
4. [Current implementation status](#2-current-implementation-status)
5. [User roles](#3-user-roles)
6. [Main application areas](#4-main-application-areas)
7. [Technical architecture](#5-technical-architecture)
8. [Authentication and sessions](#6-authentication-and-sessions)
9. [Tenant isolation and security model](#7-tenant-isolation-and-security-model)
10. [Database design](#8-database-design)
11. [Project structure](#9-project-structure)
12. [Local development](#10-local-development)
13. [VS Code workflow](#11-vs-code-workflow)
14. [Deployment](#12-deployment)
15. [Operational procedures](#13-operational-procedures)
16. [Testing and validation evidence](#14-testing-and-validation-evidence)
17. [Backup, privacy and data handling](#15-backup-privacy-and-data-handling)
18. [Troubleshooting](#16-troubleshooting)
19. [Recommended next implementation sequence](#17-recommended-next-implementation-sequence)
20. [Reference files](#18-reference-files)

The table of contents follows the current documentation structure. GitHub, VS Code and most Markdown viewers can use the links to jump directly to a section.

---

## 1. System overview

SmartSchool Ghana is a mobile-responsive, database-backed school management platform for Ghanaian schools serving nursery, kindergarten, primary, JHS and SHS learners.

The platform provides a single operating workspace for school setup, student admissions, staff records, academic structure, attendance, finance, examinations, timetables, communications, library resources, assets and reports.

SmartSchool is designed around four principles:

1. **Real records only:** Dashboard numbers are derived from database records. A new school begins with zero students, zero staff, zero payments, zero attendance sessions and zero exams.
2. **Tenant isolation:** Each school operates as a separate tenant. School data is scoped through authenticated school membership and is not shared with other schools.
3. **Role-based access:** Users receive application roles that control which areas they can view or manage.
4. **Persistent operations:** Records are stored in managed MySQL through Drizzle ORM. Browser state is not the primary database.

SmartSchool is a separate project and resource from the PULLINGS project. It has its own source tree, database schema, migrations, repository history and checkpoints.

---

## 2. Current implementation status

The current project includes a working foundation and several database-backed operations modules.

### Implemented

- Manus OAuth login flow from the managed Web starter.
- Responsive public landing page and authenticated school workspace.
- School onboarding and school settings for core identity/contact fields.
- Tenant-aware school context resolution.
- Zero-state dashboard with derived student, staff, payment and activity metrics.
- Student admissions with persistent database records.
- Student profile photographs uploaded to durable managed storage and referenced by stable storage paths.
- Academic levels and classes.
- Staff profiles.
- Manual payment recording for cash, MTN Mobile Money, Telecel Cash, AT Money and bank transfer.
- Published announcements with audience filtering.
- Attendance session creation.
- Timetable entries with server-side class and room conflict prevention.
- Exam scheduling records.
- Library book catalogue records and copy counts.
- School asset and inventory records.
- CSV downloads for admissions and payments.
- Additive Drizzle migrations.
- Responsive mobile, tablet and desktop layouts.
- Health endpoint and route manifest.
- TypeScript checking, production build and automated starter tests.

### Still planned or incomplete

The following capabilities remain explicitly open in `TODO.md` and should not be represented as complete:

- Guardian records, student-guardian links and parent portal.
- Student portal and linked learner access.
- User invitations, membership administration and complete role assignment workflows.
- Per-student attendance records and attendance summaries.
- Fee structures, student charges, discounts, balances and expenses.
- Secure Paystack configuration and server-side verification.
- Exam subjects, score entry, grade calculation and report cards.
- Library issue/return circulation and borrower links.
- Direct messaging and message read state.
- Full downloadable reports for attendance, exams, library and assets.
- School logo/branding upload and academic-year configuration.
- Audit log persistence.
- Foreign-key enforcement and broader cross-entity integrity checks.

---

## 3. User roles

SmartSchool defines the following application roles:

| Role | Intended responsibility |
|---|---|
| Super Administrator | Manage schools, global configuration, memberships and platform-level administration. |
| School Administrator | Manage school settings, users, academics, admissions, staff and operational records. |
| Headteacher / Principal | Oversee academic structure, staff, attendance, exams, timetable and school operations. |
| Accountant | Manage finance records, receipts and financial operations. |
| Teacher | Manage assigned teaching activities, attendance, examinations and class-related information. |
| Student | View personal school information, timetable, attendance, grades and published reports when portal features are enabled. |
| Parent / Guardian | View linked learners, fees, attendance, announcements and published reports when guardian features are enabled. |
| Librarian | Manage library catalogue and circulation when library circulation features are enabled. |

### Role enforcement

Protected tRPC procedures obtain the authenticated user from the Manus session and resolve the user's school membership. Procedures then apply role checks before allowing the operation.

Role names are stored as application data:

```text
super_admin
school_admin
headteacher
accountant
teacher
student
parent
librarian
```

The current implementation has role guards for the delivered modules. Full membership management and linked student/parent portals remain future work.

---

## 4. Main application areas

### 4.1 Overview dashboard

Route: `/`

The overview dashboard shows operational signals derived from persistent records, including:

- Total students.
- Total staff profiles.
- Cash recorded.
- Recent admissions.
- Recent school activity.
- Empty-state guidance when no records exist.

No fake values are seeded. A new school displays zero or an empty state until the school creates real records.

### 4.2 Students and admissions

Route: `/students`

The admissions workflow supports:

- Admission number.
- First name, middle name and last name.
- Date of birth.
- Gender.
- Phone and email.
- Address.
- Persistent profile photograph.
- Student status.

Admission numbers are unique within a school. Student records are written to the `students` table and survive refreshes, logout, server restart and deployment.

#### Student photo handling

1. The user selects a PNG, JPEG or WebP image.
2. The client limits the file to 5 MB.
3. The server validates the data URL and image type.
4. The server uploads the bytes through the managed storage helper.
5. A stable `/manus-storage/...` reference is saved in `students.photoUrl`.
6. Future reads render the stored reference rather than a browser-only object URL.

### 4.3 Staff and roles

Route: `/staff`

The staff directory supports:

- Staff number.
- First and last name.
- Job title.
- Phone and email.
- Employment status.

Staff numbers are unique within the school. A later phase should connect staff profiles to users, departments, role memberships and staff photographs.

### 4.4 Academics

Route: `/academics`

The current academic setup supports:

- Levels.
- Nursery, kindergarten, primary, JHS and SHS stage classification.
- Classes.
- Class codes.
- Capacity.
- Optional level assignment.

The schema also contains foundations for departments, subjects, academic years and terms. Full CRUD interfaces for those entities remain planned.

### 4.5 Attendance

Route: `/attendance`

The current implementation allows authorized users to create an attendance session for a class and date.

Attendance sessions contain:

- School.
- Class.
- Date.
- User who created the session.
- Draft or submitted status.

The database also contains `attendanceRecords` for present, absent, late and excused states. Per-student attendance entry and summary reporting are planned next.

### 4.6 Fees and finance

Route: `/finance`

The current finance workspace supports verified manual receipt recording.

Supported methods:

- Cash.
- MTN Mobile Money.
- Telecel Cash.
- AT Money.
- Bank transfer.

Each receipt can contain:

- Receipt number.
- Amount in GHS.
- Payment method.
- Provider reference.
- Payment date.
- Verification status.
- Receiving user.

Receipt numbers are unique within a school. Finance totals are calculated from stored payments.

#### Paystack policy

Paystack is not presented as an active payment path in the current implementation. It must remain disabled until all of the following exist:

- Secure server-side secret configuration.
- Verified provider configuration.
- Server-side payment verification.
- No secret keys exposed to browser code.
- Durable provider references and payment status handling.

### 4.7 Communications

Route: `/communications`

Authorized users can publish school announcements with an audience of:

- Everyone.
- Staff.
- Students.
- Parents / guardians.

Announcements are stored in the `announcements` table. Audience filtering is applied when records are read. Direct messaging and read-state tracking remain planned.

### 4.8 Timetable

Route: `/timetable`

Timetable entries support:

- Class.
- Subject label.
- Teacher label.
- Weekday.
- Start time.
- End time.
- Room.

The server rejects an entry when it overlaps an existing entry for the same class or room on the same weekday. End time must be later than start time.

### 4.9 Examinations

Route: `/exams`

The current implementation creates examination calendar records with:

- Title.
- Type.
- Start date.
- End date.
- Draft, published or closed status.

Exam subjects, score entry, grade calculation and report cards remain planned.

### 4.10 Library

Route: `/library`

The current library catalogue supports:

- Title.
- Author.
- ISBN.
- Category.
- Shelf.
- Total copies.
- Available copies.

A book must have at least one copy. Issue and return circulation remains planned.

### 4.11 Assets and inventory

Route: `/assets`

Asset records support:

- Asset tag.
- Name.
- Category.
- Quantity.
- Condition.
- Location.
- Active, maintenance or retired status.

Asset tags are unique within a school. Purchase date and value fields remain planned.

### 4.12 Reports

Route: `/reports`

The current report workspace provides browser-generated CSV downloads for:

- Admissions register.
- Payment ledger.

Reports are generated from records returned by protected APIs for the active school context. Attendance, examinations, library and asset reports remain planned.

### 4.13 School settings

Route: `/settings`

Current settings include:

- School name.
- School code.
- Motto.
- Phone.
- Email.
- Region.
- Town / city.
- Address.

The settings page also shows the current role and explains that tenant boundaries are enforced server-side. Logo branding and academic-year settings remain planned.

---

## 5. Technical architecture

### Frontend

- React 19.
- TypeScript.
- Vite.
- Wouter route handling.
- TanStack Query through tRPC React integration.
- Radix UI primitives.
- Lucide icons.
- Responsive CSS design system.
- Sonner toast notifications.

The primary frontend entry points are:

```text
client/src/App.tsx
client/src/pages/Home.tsx
client/src/index.css
client/src/components/ui/
client/public/manus-routes.json
```

### Backend

- Express server.
- tRPC API routers.
- Drizzle ORM.
- MySQL through the managed database environment.
- Manus OAuth starter implementation.
- Durable managed object storage for photos and other uploads.

The primary backend entry points are:

```text
server/_core/index.ts
server/_core/context.ts
server/_core/trpc.ts
server/db.ts
server/permissions.ts
server/routers.ts
server/storage.ts
```

### API style

The application uses typed tRPC procedures instead of manually maintained REST endpoints for business operations.

High-level router groups include:

```text
school
onboarding
dashboard
students
academics
staff
finance
communications
attendance
timetable
exams
library
assets
```

Each procedure should:

1. Require an authenticated session where appropriate.
2. Resolve school membership server-side.
3. Check the user's role.
4. Validate input using Zod.
5. Apply a tenant predicate to database reads and writes.
6. Return a typed result or a user-readable error.

---

## 6. Authentication and sessions

SmartSchool uses the Manus OAuth flow supplied by the managed Web starter.

The authentication flow is:

1. A visitor selects Sign in.
2. The application redirects to the Manus OAuth authorization flow.
3. The callback validates the state and nonce values.
4. The application exchanges the authorization code.
5. The Manus identity is upserted into the application user record.
6. The server creates the application session.
7. The browser receives the managed application session cookie.
8. Protected tRPC procedures read the authenticated user from server context.

The project does not use a simulated login, browser-only user record or separate password database.

For cross-site Preview iframe compatibility, the application preserves the required secure session-cookie behavior. OAuth testing should be performed through the managed Preview rather than by inventing a local callback origin.

---

## 7. Tenant isolation and security model

Every school-owned record carries a `schoolId` directly or is reached through a school-owned parent record.

### Tenant rules

- The client must not be trusted to authorize a school.
- The active school is resolved from authenticated membership.
- Database queries include the resolved school ID.
- Mutations validate that referenced records belong to the same school.
- A normal school user cannot query another school's records.
- Super administrator multi-school management should use an explicit controlled school selection workflow.
- Payment provider secrets must never be included in browser bundles.
- Uploaded files are stored using durable managed storage references.
- Input validation happens at the tRPC boundary and again where business rules require it.

### Current security limitations to address

The following hardening work remains:

- Add foreign keys and broader relational integrity constraints.
- Add audit log records for finance, settings, identity, attendance and permissions changes.
- Complete class/teacher assignment checks.
- Complete linked student and guardian authorization.
- Add membership invitation and role-management workflows.
- Add duplicate-error messages that are friendly to end users.

---

## 8. Database design

### Identity and tenancy tables

- `users`: Manus identity anchor from the starter.
- `schools`: school tenant records and school settings.
- `schoolMemberships`: user-to-school relationship and role.

### Academic and people tables

- `academicYears`.
- `terms`.
- `levels`.
- `departments`.
- `classes`.
- `subjects`.
- `students`.
- `guardians`.
- `studentGuardians`.
- `staffProfiles`.

### Operations tables

- `attendanceSessions`.
- `attendanceRecords`.
- `timetableEntries`.
- `announcements`.
- `exams`.
- `payments`.
- `expenses`.
- `libraryBooks`.
- `assets`.

### Migration history

```text
drizzle/0000_initial_users.sql
drizzle/0001_lying_titanium_man.sql
drizzle/0002_overrated_miek.sql
```

The migrations are additive. No fake students, staff, payments, attendance records, exams, books or assets are seeded.

### Data persistence policy

Use the managed MySQL database for business records. Do not use:

- `localStorage` as the primary database.
- Temporary browser arrays as the source of truth.
- Hardcoded dashboard metrics.
- Fake seed records presented as real school activity.

---

## 9. Project structure

```text
smartschool/
├── client/
│   ├── public/manus-routes.json
│   ├── src/
│   │   ├── components/ui/       Shared UI primitives
│   │   ├── _core/hooks/         Authentication and starter hooks
│   │   ├── pages/Home.tsx       Main shell and feature workspaces
│   │   ├── App.tsx              Application routes and providers
│   │   └── index.css            Design tokens and responsive styles
│   └── index.html
├── server/
│   ├── _core/                   Express, OAuth, context and tRPC setup
│   ├── db.ts                    Database queries and business helpers
│   ├── permissions.ts           Role and tenant guards
│   ├── routers.ts               tRPC procedure definitions
│   └── storage.ts               Durable managed-storage helpers
├── drizzle/
│   ├── schema.ts                Drizzle relational schema
│   ├── relations.ts             Drizzle relations
│   └── *.sql                    Additive migrations
├── docs/
│   └── SMARTSCHOOL_SYSTEM_DOCUMENTATION.md
├── plan.md                      Architecture and design plan
├── TODO.md                      Implementation status checklist
├── README.md                    Quick setup guide
├── Dockerfile                   Production container definition
├── app.config.ts                Project logo metadata
└── package.json                 Scripts and dependencies
```

---

## 10. Local development

### Requirements

- Node.js 22 or newer.
- pnpm 10.18.0.
- Managed project environment variables.
- Managed MySQL `DATABASE_URL`.
- Manus OAuth environment values.
- Application session secret.

### Installation

From the project root:

```bash
pnpm install
```

### Database migration

Apply committed migrations:

```bash
pnpm db:migrate
```

For schema changes during development, generate and apply an additive migration:

```bash
pnpm db:push
```

Review generated SQL before committing it.

### Start development server

```bash
pnpm dev
```

The default development port is `3000`.

### Quality checks

```bash
pnpm check
pnpm test
pnpm build
```

### Production start

After building:

```bash
pnpm start
```

The production server starts from `dist/index.js` and honors the `PORT` environment variable.

---

## 11. VS Code workflow

1. Open `/home/ubuntu/smartschool` as the workspace.
2. Open the integrated terminal.
3. Run `pnpm install` if dependencies are not installed.
4. Run `pnpm dev`.
5. Use the managed Preview for OAuth testing.
6. Use `pnpm check` before committing TypeScript changes.
7. Use `pnpm test` for automated tests.
8. Use `pnpm build` to verify the production bundle.
9. Keep secrets and local `.env` files outside Git.

Do not manually modify generated migration history without understanding the existing Drizzle journal.

---

## 12. Deployment

SmartSchool is configured as a managed server-backed Web project.

Deployment uses:

- The committed `Dockerfile`.
- The production server bundle.
- Managed runtime environment variables.
- Managed MySQL persistence.
- Health endpoint: `/api/health`.

Before deployment:

```bash
pnpm check
pnpm test
pnpm build
curl http://localhost:3000/api/health
```

The expected health response is:

```json
{"status":"ok"}
```

Do not copy local `.env` files into the container. Do not commit credentials. Publish only a committed canonical checkpoint.

---

## 13. Operational procedures

### Creating a school

1. Sign in using Manus OAuth.
2. Complete the school onboarding form.
3. Confirm the school name and code.
4. Open School settings and add contact/location information.
5. Open Academics and create levels and classes.
6. Add staff profiles.
7. Admit students.
8. Record payments only when a real payment has been received.

### Recording a student

1. Open Students.
2. Select Add student.
3. Enter the admission number and required name fields.
4. Add optional contact and demographic information.
5. Select a validated photograph if available.
6. Submit the admission form.
7. Confirm the student appears in the admissions register.

### Recording a payment

1. Open Fees & finance.
2. Select Record payment.
3. Enter a unique receipt number.
4. Enter the amount in GHS.
5. Select the actual payment method.
6. Add a provider reference where applicable.
7. Submit the receipt.
8. Confirm the payment appears in the ledger and dashboard total.

### Creating a timetable entry

1. Open Timetable.
2. Select Add entry.
3. Select a class where applicable.
4. Enter the subject and time range.
5. Add a room if the lesson uses a specific room.
6. Submit the entry.
7. If it overlaps an existing class or room entry, correct the time or location and submit again.

### Recommended school setup procedure

Complete school configuration in this order so later records have the correct context:

1. Create or confirm the school tenant.
2. Enter the school's official name, code, contact details, region, town and address.
3. Create the educational levels used by the school.
4. Create classes and assign capacity where known.
5. Create staff profiles and confirm their job titles.
6. Define subjects, departments, academic years and terms when those interfaces are enabled.
7. Review role memberships before inviting staff into daily workflows.
8. Admit students using the school's official admission numbers.
9. Confirm that dashboard totals reflect the records just created.

Do not create placeholder students, staff, payments or exams to make the dashboard look populated.

### Student admission procedure

Use the following control points for each admission:

1. Confirm that the learner has been approved for admission by the school.
2. Search the register or verify the admission number to avoid duplicates.
3. Enter the learner's legal name and available demographic details.
4. Add a current contact method where appropriate.
5. Upload a photograph only with the school's authorization and within the supported file limit.
6. Review the form before saving.
7. Submit the record and wait for the success notification.
8. Reopen or refresh the register to confirm database persistence.
9. Complete guardian, enrollment and class assignment steps when those modules are available.

### Academic setup procedure

1. Open Academics.
2. Add levels using names that match the school's official structure, such as Primary 1 or JHS 2.
3. Select the correct stage: nursery, kindergarten, primary, JHS or SHS.
4. Add each class and use a unique class code.
5. Set capacity where the school uses capacity planning.
6. Review the structure before admitting large numbers of learners.
7. Add departments, subjects, terms and academic years as those features become available.

### Attendance procedure

The current implementation creates the session record. The intended complete daily procedure is:

1. Teacher or authorized administrator signs in.
2. Confirm the correct school, class and date.
3. Create one attendance session for that class and date.
4. Record each learner as present, absent, late or excused.
5. Add a note only when it helps explain an exception.
6. Review the register for omissions and duplicate entries.
7. Submit or close the session when the class register is verified.
8. Review attendance summaries after per-student attendance recording is enabled.

### Finance and receipt procedure

1. Confirm that the payment has actually been received.
2. Open Fees & finance and select Record payment.
3. Use a receipt number from the school's controlled receipt sequence.
4. Enter the exact amount in Ghana cedis.
5. Select the real channel used: cash, MTN Mobile Money, Telecel Cash, AT Money or bank transfer.
6. Add the provider or bank reference where one exists.
7. Review the amount, method and receipt number.
8. Save the receipt once.
9. Confirm it appears in the payment ledger.
10. Retain any external payment evidence according to the school's finance policy.

Do not record an unverified Paystack payment. Paystack must remain disabled until secure server-side configuration and verification are implemented.

### Announcement procedure

1. Confirm that the message is appropriate for the selected audience.
2. Open Communications and select New announcement.
3. Write a specific title and concise message.
4. Select Everyone, Staff, Students or Parents / guardians.
5. Check names, dates, times and instructions before publishing.
6. Publish the message.
7. Correct or follow up through an additional announcement if important information changes.

### Timetable review procedure

1. Collect the approved weekly teaching schedule.
2. Add entries with the correct class, subject, day, start time and end time.
3. Add teacher and room information where available.
4. Resolve any server-reported class or room conflict before proceeding.
5. Review the entire week for gaps, overlaps and unavailable rooms.
6. Communicate the approved schedule to teachers and learners through the school's normal channel.

### Library and asset procedure

For library books:

1. Add each title once with author, category, shelf and total copies.
2. Confirm available copies match the physical count.
3. Reconcile the catalogue during periodic stock checks.
4. Use the future circulation workflow for issue and return transactions.

For school assets:

1. Assign a unique asset tag.
2. Record the asset name, category, quantity, condition and location.
3. Update condition or status when an asset moves, enters maintenance or retires.
4. Reconcile the digital register with physical inventory during scheduled reviews.

### Report download procedure

1. Confirm that the active school context is correct.
2. Open Reports.
3. Select the required CSV export.
4. Store the downloaded report in an access-controlled location.
5. Share it only with authorized recipients.
6. Delete temporary copies when the school's retention policy permits.

### Logout and access review procedure

1. Sign out when leaving a shared device.
2. Do not save school credentials in a public or shared browser profile.
3. Review staff roles when an employee changes responsibility or leaves the school.
4. Suspend or remove access through the membership workflow when it becomes available.
5. Report unexpected access, incorrect school data or suspicious payment activity to the school administrator.

---

## 14. Testing and validation evidence

The following checks are used for the current implementation:

| Check | Purpose |
|---|---|
| `pnpm check` | TypeScript diagnostics. |
| `pnpm test` | Vitest automated tests for starter platform/auth behavior. |
| `pnpm build` | Client and server production compilation. |
| `/api/health` | Runtime health response. |
| `/manus-routes.json` | Route manifest availability and validity. |
| Empty database count check | Confirms no fake operational records are seeded. |
| Read-only implementation audit | Reviews tenant checks, role checks, persistence and requirement status. |

The current starter test suite verifies OAuth/session platform behavior. Feature-specific tests should be expanded as attendance entry, fee structures, grade entry, portals, library circulation and membership workflows are completed.

---

## 15. Backup, privacy and data handling

Operational records are stored in the managed project database. Photos and other uploaded files use managed durable storage.

Administrators should:

- Avoid entering unnecessary sensitive personal information.
- Use correct admission numbers and receipt references.
- Protect access to Manus accounts.
- Review membership roles regularly.
- Avoid sharing exported CSV reports publicly.
- Treat student and guardian information as confidential.
- Never place provider secrets in frontend code or committed files.

A future production hardening phase should add formal audit logs, retention rules, export access logs and more granular guardian/student authorization.

---

## 16. Troubleshooting

### The application does not start

Run:

```bash
pnpm install
pnpm check
pnpm dev
```

Confirm that the configured port is available and that managed environment variables are loaded.

### Database errors occur

Check that `DATABASE_URL` is supplied by the managed project environment. Then run:

```bash
pnpm db:migrate
```

Do not replace the database with a local browser store.

### OAuth does not complete

Use the managed Preview origin and confirm the project is running. Do not invent a different callback URL or expose session values in logs.

### A duplicate record is rejected

Admission numbers, school codes, class codes, receipt numbers and asset tags are unique within their relevant school scope. Choose a new identifier.

### A timetable entry is rejected

Check whether the class or room already has an overlapping entry on the same weekday. Also confirm that the end time is later than the start time.

### A photo does not appear

Confirm that the upload is PNG, JPEG or WebP and no larger than 5 MB. The database should contain a stable `/manus-storage/` reference after a successful admission.

---

## 17. Recommended next implementation sequence

1. Complete guardian records, student-guardian links and membership invitations.
2. Add student enrollment by academic year, term and class.
3. Implement per-student attendance entry and summaries.
4. Add fee structures, charges, balances, discounts and expenses.
5. Add exam subjects, score entry, grade calculation and report cards.
6. Add student and parent portals with linked-record authorization.
7. Add library circulation and borrower links.
8. Add audit logs and foreign-key integrity.
9. Expand reports for attendance, exams, library and assets.
10. Add branding uploads and academic-year/term configuration.
11. Add feature-specific automated tests for every major workflow.

The authoritative progress state is maintained in `TODO.md`.

---

## 18. Reference files

- [Architecture plan](../plan.md)
- [Delivery checklist](../TODO.md)
- [Quick setup README](../README.md)
- [Database schema](../drizzle/schema.ts)
- [Database migrations](../drizzle/)
- [Server routers](../server/routers.ts)
- [Tenant and role permissions](../server/permissions.ts)
- [Database helpers](../server/db.ts)
- [Durable storage helper](../server/storage.ts)
