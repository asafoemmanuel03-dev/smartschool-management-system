# SmartSchool Ghana

SmartSchool is a tenant-isolated school management platform for Ghanaian schools covering nursery, kindergarten, primary, JHS and SHS. It uses Manus OAuth, the managed Web database starter, React, Express, tRPC and Drizzle.

For the full product, technical, database, security, operations and deployment reference, see [SmartSchool System Documentation](docs/SMARTSCHOOL_SYSTEM_DOCUMENTATION.md).

## Local development

Use Node.js 22+ and pnpm 10.18.0. From the project root:

```bash
pnpm install
pnpm db:migrate
pnpm dev
```

The full application listens on port 3000 by default. `DATABASE_URL`, Manus OAuth environment values and the application session secret are supplied by the managed project environment; do not commit them or put private provider keys in client code.

Useful checks:

```bash
pnpm check
pnpm test
pnpm build
```

The shared managed database is used by development and published environments. Do not seed fake operational records. Test with deliberate, clearly identified records and remove only records you created when a workflow requires cleanup.

## VS Code

Open `/home/ubuntu/smartschool` as the workspace. Use the integrated terminal for the commands above. TypeScript diagnostics are registered by the managed WebDev runtime. Keep `.env`, generated credentials and local secrets out of Git. Use the WebDev Preview for OAuth redirect behavior because the Preview proxy supplies the supported application session cookie flow.

## Data and access model

The database schema lives in `drizzle/schema.ts`. Additive migrations are generated and applied with `pnpm db:push`, then committed under `drizzle/`. Every school-owned query must include an authenticated membership-derived `schoolId` predicate. Roles are application data: `super_admin`, `school_admin`, `headteacher`, `accountant`, `teacher`, `student`, `parent` and `librarian`.

Student photos and other durable uploads belong in managed storage, with their stable storage path indexed in MySQL. The admissions flow validates PNG, JPEG and WebP uploads up to 5MB, stores the stable `/manus-storage/` reference in the student row, and renders that stored reference on later reads.

## Deployment

The managed project builds from the canonical checkpoint using `Dockerfile`, starts `dist/index.js`, honors `PORT`, and exposes the unauthenticated `/api/health` endpoint. The database survives process restarts and deployments. Deployment configuration is owned by the WebDev project, so publish only a committed checkpoint and never copy a local `.env` into the image.
