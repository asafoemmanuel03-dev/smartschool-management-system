CREATE TABLE `academicYears` (
	`id` int AUTO_INCREMENT NOT NULL,
	`schoolId` int NOT NULL,
	`name` varchar(80) NOT NULL,
	`startsOn` timestamp NOT NULL,
	`endsOn` timestamp NOT NULL,
	`isCurrent` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `academicYears_id` PRIMARY KEY(`id`),
	CONSTRAINT `academic_years_school_name_unique` UNIQUE(`schoolId`,`name`)
);
--> statement-breakpoint
CREATE TABLE `announcements` (
	`id` int AUTO_INCREMENT NOT NULL,
	`schoolId` int NOT NULL,
	`title` varchar(180) NOT NULL,
	`body` text NOT NULL,
	`audience` enum('all','staff','students','parents') NOT NULL DEFAULT 'all',
	`status` enum('draft','published','archived') NOT NULL DEFAULT 'draft',
	`publishedAt` timestamp,
	`publishedByUserId` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `announcements_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `attendanceSessions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`schoolId` int NOT NULL,
	`classId` int NOT NULL,
	`termId` int,
	`date` timestamp NOT NULL,
	`takenByUserId` int NOT NULL,
	`status` enum('draft','submitted') NOT NULL DEFAULT 'draft',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `attendanceSessions_id` PRIMARY KEY(`id`),
	CONSTRAINT `attendance_sessions_class_date_unique` UNIQUE(`classId`,`date`)
);
--> statement-breakpoint
CREATE TABLE `classes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`schoolId` int NOT NULL,
	`levelId` int,
	`departmentId` int,
	`name` varchar(120) NOT NULL,
	`code` varchar(30) NOT NULL,
	`stream` varchar(30),
	`capacity` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `classes_id` PRIMARY KEY(`id`),
	CONSTRAINT `classes_school_code_unique` UNIQUE(`schoolId`,`code`)
);
--> statement-breakpoint
CREATE TABLE `departments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`schoolId` int NOT NULL,
	`name` varchar(120) NOT NULL,
	`code` varchar(30) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `departments_id` PRIMARY KEY(`id`),
	CONSTRAINT `departments_school_code_unique` UNIQUE(`schoolId`,`code`)
);
--> statement-breakpoint
CREATE TABLE `expenses` (
	`id` int AUTO_INCREMENT NOT NULL,
	`schoolId` int NOT NULL,
	`category` varchar(100) NOT NULL,
	`description` text NOT NULL,
	`amount` varchar(30) NOT NULL,
	`expenseDate` timestamp NOT NULL DEFAULT (now()),
	`status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
	`recordedByUserId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `expenses_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `guardians` (
	`id` int AUTO_INCREMENT NOT NULL,
	`schoolId` int NOT NULL,
	`userId` int,
	`name` varchar(180) NOT NULL,
	`relationship` varchar(80),
	`phone` varchar(40),
	`email` varchar(320),
	`address` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `guardians_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `levels` (
	`id` int AUTO_INCREMENT NOT NULL,
	`schoolId` int NOT NULL,
	`name` varchar(100) NOT NULL,
	`stage` enum('nursery','kindergarten','primary','jhs','shs') NOT NULL,
	`sortOrder` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `levels_id` PRIMARY KEY(`id`),
	CONSTRAINT `levels_school_name_unique` UNIQUE(`schoolId`,`name`)
);
--> statement-breakpoint
CREATE TABLE `payments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`schoolId` int NOT NULL,
	`studentId` int,
	`receiptNumber` varchar(60) NOT NULL,
	`amount` varchar(30) NOT NULL,
	`method` enum('cash','mtn_momo','telecel_cash','at_money','bank_transfer','paystack') NOT NULL,
	`providerReference` varchar(160),
	`status` enum('pending','verified','reversed') NOT NULL DEFAULT 'verified',
	`paidOn` timestamp NOT NULL DEFAULT (now()),
	`receivedByUserId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `payments_id` PRIMARY KEY(`id`),
	CONSTRAINT `payments_school_receipt_unique` UNIQUE(`schoolId`,`receiptNumber`)
);
--> statement-breakpoint
CREATE TABLE `schoolMemberships` (
	`id` int AUTO_INCREMENT NOT NULL,
	`schoolId` int NOT NULL,
	`userId` int NOT NULL,
	`role` enum('super_admin','school_admin','headteacher','accountant','teacher','student','parent','librarian') NOT NULL DEFAULT 'school_admin',
	`status` enum('active','invited','suspended') NOT NULL DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `schoolMemberships_id` PRIMARY KEY(`id`),
	CONSTRAINT `school_memberships_school_user_unique` UNIQUE(`schoolId`,`userId`)
);
--> statement-breakpoint
CREATE TABLE `schools` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(180) NOT NULL,
	`code` varchar(32) NOT NULL,
	`slug` varchar(180) NOT NULL,
	`motto` varchar(255),
	`phone` varchar(40),
	`email` varchar(320),
	`address` text,
	`region` varchar(80),
	`town` varchar(100),
	`logoUrl` text,
	`currency` varchar(8) NOT NULL DEFAULT 'GHS',
	`status` enum('active','suspended') NOT NULL DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `schools_id` PRIMARY KEY(`id`),
	CONSTRAINT `schools_code_unique` UNIQUE(`code`),
	CONSTRAINT `schools_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
CREATE TABLE `staffProfiles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`schoolId` int NOT NULL,
	`userId` int,
	`staffNumber` varchar(50) NOT NULL,
	`firstName` varchar(100) NOT NULL,
	`lastName` varchar(100) NOT NULL,
	`jobTitle` varchar(120) NOT NULL,
	`phone` varchar(40),
	`email` varchar(320),
	`departmentId` int,
	`photoUrl` text,
	`employmentStatus` enum('active','inactive','on_leave') NOT NULL DEFAULT 'active',
	`joinedOn` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `staffProfiles_id` PRIMARY KEY(`id`),
	CONSTRAINT `staff_profiles_school_number_unique` UNIQUE(`schoolId`,`staffNumber`)
);
--> statement-breakpoint
CREATE TABLE `studentGuardians` (
	`id` int AUTO_INCREMENT NOT NULL,
	`schoolId` int NOT NULL,
	`studentId` int NOT NULL,
	`guardianId` int NOT NULL,
	`isPrimary` int NOT NULL DEFAULT 0,
	CONSTRAINT `studentGuardians_id` PRIMARY KEY(`id`),
	CONSTRAINT `student_guardians_student_guardian_unique` UNIQUE(`studentId`,`guardianId`)
);
--> statement-breakpoint
CREATE TABLE `students` (
	`id` int AUTO_INCREMENT NOT NULL,
	`schoolId` int NOT NULL,
	`admissionNumber` varchar(50) NOT NULL,
	`firstName` varchar(100) NOT NULL,
	`middleName` varchar(100),
	`lastName` varchar(100) NOT NULL,
	`dateOfBirth` timestamp,
	`gender` enum('female','male','other'),
	`nationalId` varchar(80),
	`photoUrl` text,
	`phone` varchar(40),
	`email` varchar(320),
	`address` text,
	`classId` int,
	`status` enum('active','inactive','graduated','withdrawn') NOT NULL DEFAULT 'active',
	`admissionDate` timestamp NOT NULL DEFAULT (now()),
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `students_id` PRIMARY KEY(`id`),
	CONSTRAINT `students_school_admission_unique` UNIQUE(`schoolId`,`admissionNumber`)
);
--> statement-breakpoint
CREATE TABLE `subjects` (
	`id` int AUTO_INCREMENT NOT NULL,
	`schoolId` int NOT NULL,
	`departmentId` int,
	`code` varchar(30) NOT NULL,
	`name` varchar(120) NOT NULL,
	`stage` enum('nursery','kindergarten','primary','jhs','shs') NOT NULL,
	`isCore` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `subjects_id` PRIMARY KEY(`id`),
	CONSTRAINT `subjects_school_code_unique` UNIQUE(`schoolId`,`code`)
);
--> statement-breakpoint
CREATE TABLE `terms` (
	`id` int AUTO_INCREMENT NOT NULL,
	`schoolId` int NOT NULL,
	`academicYearId` int NOT NULL,
	`name` varchar(80) NOT NULL,
	`startsOn` timestamp NOT NULL,
	`endsOn` timestamp NOT NULL,
	`status` enum('planned','active','closed') NOT NULL DEFAULT 'planned',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `terms_id` PRIMARY KEY(`id`)
);
