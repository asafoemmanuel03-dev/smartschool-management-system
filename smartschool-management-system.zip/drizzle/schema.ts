import {
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const schools = mysqlTable("schools", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 180 }).notNull(),
  code: varchar("code", { length: 32 }).notNull(),
  slug: varchar("slug", { length: 180 }).notNull(),
  motto: varchar("motto", { length: 255 }),
  phone: varchar("phone", { length: 40 }),
  email: varchar("email", { length: 320 }),
  address: text("address"),
  region: varchar("region", { length: 80 }),
  town: varchar("town", { length: 100 }),
  logoUrl: text("logoUrl"),
  currency: varchar("currency", { length: 8 }).default("GHS").notNull(),
  status: mysqlEnum("status", ["active", "suspended"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => ({
  codeUnique: uniqueIndex("schools_code_unique").on(table.code),
  slugUnique: uniqueIndex("schools_slug_unique").on(table.slug),
}));

export const schoolMemberships = mysqlTable("schoolMemberships", {
  id: int("id").autoincrement().primaryKey(),
  schoolId: int("schoolId").notNull(),
  userId: int("userId").notNull(),
  role: mysqlEnum("role", [
    "super_admin",
    "school_admin",
    "headteacher",
    "accountant",
    "teacher",
    "student",
    "parent",
    "librarian",
  ]).default("school_admin").notNull(),
  status: mysqlEnum("status", ["active", "invited", "suspended"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => ({
  schoolUserUnique: uniqueIndex("school_memberships_school_user_unique").on(table.schoolId, table.userId),
}));

export const academicYears = mysqlTable("academicYears", {
  id: int("id").autoincrement().primaryKey(),
  schoolId: int("schoolId").notNull(),
  name: varchar("name", { length: 80 }).notNull(),
  startsOn: timestamp("startsOn").notNull(),
  endsOn: timestamp("endsOn").notNull(),
  isCurrent: int("isCurrent").default(1).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => ({
  schoolYearUnique: uniqueIndex("academic_years_school_name_unique").on(table.schoolId, table.name),
}));

export const terms = mysqlTable("terms", {
  id: int("id").autoincrement().primaryKey(),
  schoolId: int("schoolId").notNull(),
  academicYearId: int("academicYearId").notNull(),
  name: varchar("name", { length: 80 }).notNull(),
  startsOn: timestamp("startsOn").notNull(),
  endsOn: timestamp("endsOn").notNull(),
  status: mysqlEnum("status", ["planned", "active", "closed"]).default("planned").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const levels = mysqlTable("levels", {
  id: int("id").autoincrement().primaryKey(),
  schoolId: int("schoolId").notNull(),
  name: varchar("name", { length: 100 }).notNull(),
  stage: mysqlEnum("stage", ["nursery", "kindergarten", "primary", "jhs", "shs"]).notNull(),
  sortOrder: int("sortOrder").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => ({
  schoolLevelUnique: uniqueIndex("levels_school_name_unique").on(table.schoolId, table.name),
}));

export const departments = mysqlTable("departments", {
  id: int("id").autoincrement().primaryKey(),
  schoolId: int("schoolId").notNull(),
  name: varchar("name", { length: 120 }).notNull(),
  code: varchar("code", { length: 30 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => ({
  departmentCodeUnique: uniqueIndex("departments_school_code_unique").on(table.schoolId, table.code),
}));

export const classes = mysqlTable("classes", {
  id: int("id").autoincrement().primaryKey(),
  schoolId: int("schoolId").notNull(),
  levelId: int("levelId"),
  departmentId: int("departmentId"),
  name: varchar("name", { length: 120 }).notNull(),
  code: varchar("code", { length: 30 }).notNull(),
  stream: varchar("stream", { length: 30 }),
  capacity: int("capacity").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => ({
  classCodeUnique: uniqueIndex("classes_school_code_unique").on(table.schoolId, table.code),
}));

export const subjects = mysqlTable("subjects", {
  id: int("id").autoincrement().primaryKey(),
  schoolId: int("schoolId").notNull(),
  departmentId: int("departmentId"),
  code: varchar("code", { length: 30 }).notNull(),
  name: varchar("name", { length: 120 }).notNull(),
  stage: mysqlEnum("stage", ["nursery", "kindergarten", "primary", "jhs", "shs"]).notNull(),
  isCore: int("isCore").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => ({
  subjectCodeUnique: uniqueIndex("subjects_school_code_unique").on(table.schoolId, table.code),
}));

export const students = mysqlTable("students", {
  id: int("id").autoincrement().primaryKey(),
  schoolId: int("schoolId").notNull(),
  admissionNumber: varchar("admissionNumber", { length: 50 }).notNull(),
  firstName: varchar("firstName", { length: 100 }).notNull(),
  middleName: varchar("middleName", { length: 100 }),
  lastName: varchar("lastName", { length: 100 }).notNull(),
  dateOfBirth: timestamp("dateOfBirth"),
  gender: mysqlEnum("gender", ["female", "male", "other"]),
  nationalId: varchar("nationalId", { length: 80 }),
  photoUrl: text("photoUrl"),
  phone: varchar("phone", { length: 40 }),
  email: varchar("email", { length: 320 }),
  address: text("address"),
  classId: int("classId"),
  status: mysqlEnum("status", ["active", "inactive", "graduated", "withdrawn"]).default("active").notNull(),
  admissionDate: timestamp("admissionDate").defaultNow().notNull(),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => ({
  studentAdmissionUnique: uniqueIndex("students_school_admission_unique").on(table.schoolId, table.admissionNumber),
}));

export const guardians = mysqlTable("guardians", {
  id: int("id").autoincrement().primaryKey(),
  schoolId: int("schoolId").notNull(),
  userId: int("userId"),
  name: varchar("name", { length: 180 }).notNull(),
  relationship: varchar("relationship", { length: 80 }),
  phone: varchar("phone", { length: 40 }),
  email: varchar("email", { length: 320 }),
  address: text("address"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const studentGuardians = mysqlTable("studentGuardians", {
  id: int("id").autoincrement().primaryKey(),
  schoolId: int("schoolId").notNull(),
  studentId: int("studentId").notNull(),
  guardianId: int("guardianId").notNull(),
  isPrimary: int("isPrimary").default(0).notNull(),
}, table => ({
  studentGuardianUnique: uniqueIndex("student_guardians_student_guardian_unique").on(table.studentId, table.guardianId),
}));

export const staffProfiles = mysqlTable("staffProfiles", {
  id: int("id").autoincrement().primaryKey(),
  schoolId: int("schoolId").notNull(),
  userId: int("userId"),
  staffNumber: varchar("staffNumber", { length: 50 }).notNull(),
  firstName: varchar("firstName", { length: 100 }).notNull(),
  lastName: varchar("lastName", { length: 100 }).notNull(),
  jobTitle: varchar("jobTitle", { length: 120 }).notNull(),
  phone: varchar("phone", { length: 40 }),
  email: varchar("email", { length: 320 }),
  departmentId: int("departmentId"),
  photoUrl: text("photoUrl"),
  employmentStatus: mysqlEnum("employmentStatus", ["active", "inactive", "on_leave"]).default("active").notNull(),
  joinedOn: timestamp("joinedOn"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => ({
  staffNumberUnique: uniqueIndex("staff_profiles_school_number_unique").on(table.schoolId, table.staffNumber),
}));

export const attendanceSessions = mysqlTable("attendanceSessions", {
  id: int("id").autoincrement().primaryKey(),
  schoolId: int("schoolId").notNull(),
  classId: int("classId").notNull(),
  termId: int("termId"),
  date: timestamp("date").notNull(),
  takenByUserId: int("takenByUserId").notNull(),
  status: mysqlEnum("status", ["draft", "submitted"]).default("draft").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => ({
  classDateUnique: uniqueIndex("attendance_sessions_class_date_unique").on(table.classId, table.date),
}));

export const payments = mysqlTable("payments", {
  id: int("id").autoincrement().primaryKey(),
  schoolId: int("schoolId").notNull(),
  studentId: int("studentId"),
  receiptNumber: varchar("receiptNumber", { length: 60 }).notNull(),
  amount: varchar("amount", { length: 30 }).notNull(),
  method: mysqlEnum("method", ["cash", "mtn_momo", "telecel_cash", "at_money", "bank_transfer", "paystack"]).notNull(),
  providerReference: varchar("providerReference", { length: 160 }),
  status: mysqlEnum("status", ["pending", "verified", "reversed"]).default("verified").notNull(),
  paidOn: timestamp("paidOn").defaultNow().notNull(),
  receivedByUserId: int("receivedByUserId").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => ({
  receiptUnique: uniqueIndex("payments_school_receipt_unique").on(table.schoolId, table.receiptNumber),
}));

export const expenses = mysqlTable("expenses", {
  id: int("id").autoincrement().primaryKey(),
  schoolId: int("schoolId").notNull(),
  category: varchar("category", { length: 100 }).notNull(),
  description: text("description").notNull(),
  amount: varchar("amount", { length: 30 }).notNull(),
  expenseDate: timestamp("expenseDate").defaultNow().notNull(),
  status: mysqlEnum("status", ["pending", "approved", "rejected"]).default("pending").notNull(),
  recordedByUserId: int("recordedByUserId").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const announcements = mysqlTable("announcements", {
  id: int("id").autoincrement().primaryKey(),
  schoolId: int("schoolId").notNull(),
  title: varchar("title", { length: 180 }).notNull(),
  body: text("body").notNull(),
  audience: mysqlEnum("audience", ["all", "staff", "students", "parents"]).default("all").notNull(),
  status: mysqlEnum("status", ["draft", "published", "archived"]).default("draft").notNull(),
  publishedAt: timestamp("publishedAt"),
  publishedByUserId: int("publishedByUserId"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const attendanceRecords = mysqlTable("attendanceRecords", {
  id: int("id").autoincrement().primaryKey(),
  schoolId: int("schoolId").notNull(),
  sessionId: int("sessionId").notNull(),
  studentId: int("studentId").notNull(),
  status: mysqlEnum("status", ["present", "absent", "late", "excused"]).notNull(),
  note: text("note"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => ({
  sessionStudentUnique: uniqueIndex("attendance_records_session_student_unique").on(table.sessionId, table.studentId),
}));

export const exams = mysqlTable("exams", {
  id: int("id").autoincrement().primaryKey(),
  schoolId: int("schoolId").notNull(),
  title: varchar("title", { length: 180 }).notNull(),
  type: varchar("type", { length: 60 }).notNull(),
  startsOn: timestamp("startsOn").notNull(),
  endsOn: timestamp("endsOn"),
  status: mysqlEnum("status", ["draft", "published", "closed"]).default("draft").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const timetableEntries = mysqlTable("timetableEntries", {
  id: int("id").autoincrement().primaryKey(),
  schoolId: int("schoolId").notNull(),
  classId: int("classId"),
  subjectLabel: varchar("subjectLabel", { length: 120 }).notNull(),
  teacherLabel: varchar("teacherLabel", { length: 160 }),
  weekday: mysqlEnum("weekday", ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday"]).notNull(),
  startTime: varchar("startTime", { length: 5 }).notNull(),
  endTime: varchar("endTime", { length: 5 }).notNull(),
  room: varchar("room", { length: 80 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const libraryBooks = mysqlTable("libraryBooks", {
  id: int("id").autoincrement().primaryKey(),
  schoolId: int("schoolId").notNull(),
  isbn: varchar("isbn", { length: 40 }),
  title: varchar("title", { length: 180 }).notNull(),
  author: varchar("author", { length: 160 }),
  category: varchar("category", { length: 100 }),
  totalCopies: int("totalCopies").default(1).notNull(),
  availableCopies: int("availableCopies").default(1).notNull(),
  shelf: varchar("shelf", { length: 80 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const assets = mysqlTable("assets", {
  id: int("id").autoincrement().primaryKey(),
  schoolId: int("schoolId").notNull(),
  assetTag: varchar("assetTag", { length: 60 }).notNull(),
  name: varchar("name", { length: 180 }).notNull(),
  category: varchar("category", { length: 100 }),
  quantity: int("quantity").default(1).notNull(),
  condition: varchar("condition", { length: 60 }),
  location: varchar("location", { length: 120 }),
  status: mysqlEnum("status", ["active", "maintenance", "retired"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => ({
  assetTagUnique: uniqueIndex("assets_school_tag_unique").on(table.schoolId, table.assetTag),
}));

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type School = typeof schools.$inferSelect;
export type SchoolMembership = typeof schoolMemberships.$inferSelect;
export type Student = typeof students.$inferSelect;
