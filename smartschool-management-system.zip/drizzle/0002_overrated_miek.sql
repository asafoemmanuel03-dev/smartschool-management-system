CREATE TABLE `assets` (
	`id` int AUTO_INCREMENT NOT NULL,
	`schoolId` int NOT NULL,
	`assetTag` varchar(60) NOT NULL,
	`name` varchar(180) NOT NULL,
	`category` varchar(100),
	`quantity` int NOT NULL DEFAULT 1,
	`condition` varchar(60),
	`location` varchar(120),
	`status` enum('active','maintenance','retired') NOT NULL DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `assets_id` PRIMARY KEY(`id`),
	CONSTRAINT `assets_school_tag_unique` UNIQUE(`schoolId`,`assetTag`)
);
--> statement-breakpoint
CREATE TABLE `attendanceRecords` (
	`id` int AUTO_INCREMENT NOT NULL,
	`schoolId` int NOT NULL,
	`sessionId` int NOT NULL,
	`studentId` int NOT NULL,
	`status` enum('present','absent','late','excused') NOT NULL,
	`note` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `attendanceRecords_id` PRIMARY KEY(`id`),
	CONSTRAINT `attendance_records_session_student_unique` UNIQUE(`sessionId`,`studentId`)
);
--> statement-breakpoint
CREATE TABLE `exams` (
	`id` int AUTO_INCREMENT NOT NULL,
	`schoolId` int NOT NULL,
	`title` varchar(180) NOT NULL,
	`type` varchar(60) NOT NULL,
	`startsOn` timestamp NOT NULL,
	`endsOn` timestamp,
	`status` enum('draft','published','closed') NOT NULL DEFAULT 'draft',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `exams_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `libraryBooks` (
	`id` int AUTO_INCREMENT NOT NULL,
	`schoolId` int NOT NULL,
	`isbn` varchar(40),
	`title` varchar(180) NOT NULL,
	`author` varchar(160),
	`category` varchar(100),
	`totalCopies` int NOT NULL DEFAULT 1,
	`availableCopies` int NOT NULL DEFAULT 1,
	`shelf` varchar(80),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `libraryBooks_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `timetableEntries` (
	`id` int AUTO_INCREMENT NOT NULL,
	`schoolId` int NOT NULL,
	`classId` int,
	`subjectLabel` varchar(120) NOT NULL,
	`teacherLabel` varchar(160),
	`weekday` enum('monday','tuesday','wednesday','thursday','friday','saturday') NOT NULL,
	`startTime` varchar(5) NOT NULL,
	`endTime` varchar(5) NOT NULL,
	`room` varchar(80),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `timetableEntries_id` PRIMARY KEY(`id`)
);
